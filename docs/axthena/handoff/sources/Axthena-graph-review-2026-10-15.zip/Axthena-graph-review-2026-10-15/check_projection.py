"""Validate export fidelity offline. This does NOT execute or parse Cypher."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json

ROOT = Path(__file__).resolve().parent
read = lambda p: json.loads((ROOT / p).read_text(encoding='utf-8'))
g = read('graph.json')
source = read('evidence/input.json')
expected = read('evidence/combined_output_A.json')
manifest = read('projection_manifest.json')
nodes = {n['id']: n for n in g['nodes']}
outgoing, incoming = defaultdict(list), defaultdict(list)
checks = 0


def check(condition, message):
    global checks
    checks += 1
    assert condition, message


def typed(kind):
    return [n for n in nodes.values() if n['type'] == kind]


def prop(n):
    return n['properties']


def linked(n, relationship):
    return [nodes[e['to']] for e in outgoing[n['id']] if e['type'] == relationship]


def one(n, relationship):
    found = linked(n, relationship)
    check(len(found) == 1, (n['id'], relationship, 'single target required'))
    return found[0]


check(len(nodes) == len(g['nodes']), 'Unique node identities')
check(len({e['id'] for e in g['edges']}) == len(g['edges']), 'Unique edge identities')
for e in g['edges']:
    check(e['from'] in nodes and e['to'] in nodes, 'No dangling relationships')
    outgoing[e['from']].append(e)
    incoming[e['to']].append(e)
expected_counts = {'ComparisonCase':36, 'Domain':5, 'Expression':38, 'ExtractionRun':3,
    'Fixture':1, 'Idea':38, 'IdentityCase':12, 'Judgment':14, 'Organisation':6,
    'Paragraph':68, 'Passage':42, 'Person':10, 'ProcessingRecord':36,
    'Report':36, 'Source':26, 'Stock':2}
check(Counter(n['type'] for n in nodes.values()) == expected_counts, 'Expected node counts')
check(len(g['edges']) == 715, 'Expected relationship count')
for n in nodes.values():
    check(prop(n)['data_status'] == 'FICTIONAL', 'All node records labelled fictional')
    for v in prop(n).values():
        check(not isinstance(v, dict) and not (isinstance(v, list) and
              any(isinstance(x, (dict, list)) for x in v)), 'Neo4j property shape')

reports = {prop(n)['report_id']: n for n in typed('Report')}
input_reports = {r['id']: r for r in source['reports']}
processes = {prop(n)['report_id']: n for n in typed('ProcessingRecord')}
roundtrip = []
for result in expected['reports']:
    r = reports[result['id']]
    original = input_reports[result['id']]
    process = processes[result['id']]
    check(one(process, 'PROCESSED') == r, 'Processing is linked to correct report')
    for key in ['published_on', 'first_supported_available_on', 'collected_on', 'source_id',
                'source_type', 'body_status', 'confirmation_scope']:
        check(prop(r)[key] == original[key], ('Report field preserved', result['id'], key))
    paragraphs = sorted(linked(r, 'HAS_PARAGRAPH'), key=lambda n: prop(n)['position'])
    check([{'id':prop(p)['paragraph_id'], 'text':prop(p)['text']} for p in paragraphs]
          == original['paragraphs'], 'All original paragraph text retained')
    check(prop(one(r, 'PUBLISHED_IN'))['source_id'] == original['source_id'], 'Source identity')
    ideas = []
    for e in sorted(linked(r, 'CONTAINS'), key=lambda n: prop(n)['position']):
        i = one(e, 'EXPRESSES')
        check(sum(x['type'] == 'EXPRESSES' for x in incoming[i['id']]) == 1,
              'No accidental cross-report canonicalisation')
        check(e in linked(process, 'PRODUCED'), 'Expression processing provenance')
        ds = linked(i, 'ABOUT_DOMAIN')
        check(len(ds) <= 1, 'At most one retained idea domain')
        js = sorted(linked(e, 'HAS_JUDGMENT'), key=lambda n: prop(n)['position'])
        judgments = []
        for j in js:
            check(prop(one(j, 'TARGETS'))['symbol'] == prop(j)['stock'], 'Correct stock target')
            judgments.append({k:prop(j)[k] for k in ['stock','direction','window_state','start','end']})
        evidence = []
        for q in sorted(linked(e, 'SUPPORTED_BY'), key=lambda n: prop(n)['position']):
            p = one(q, 'FROM_PARAGRAPH')
            check(p in paragraphs, 'Quote belongs to its own report')
            v, text = prop(q), prop(p)['text']
            check(text[v['start_codepoint']:v['end_codepoint']] == v['quote'], 'Exact character span')
            check(text.encode()[v['start_utf8_byte']:v['end_utf8_byte']].decode() == v['quote'],
                  'Exact UTF-8 byte span')
            evidence.append({k:v[k] for k in ['paragraph_id','quote']})
        ideas.append({'summary':prop(i)['summary'],
            'org_ids':[prop(o)['org_id'] for o in linked(i,'CONCERNS')],
            'domain':prop(ds[0])['name'] if ds else None,
            'kind':prop(e)['kind'], 'event_phase':prop(e)['event_phase'],
            'judgments':judgments, 'evidence':evidence})
    roundtrip.append({'id':result['id'], 'available_on':prop(r)['available_on'],
        'processing_status':prop(process)['processing_status'],
        'cap_omitted':prop(process)['cap_omitted'], 'ideas':ideas})
check(roundtrip == expected['reports'], 'Lossless reconstruction of all 36 extracted records')

for node_type, input_key, output_key in [('IdentityCase','identity_tasks','identities'),
                                        ('ComparisonCase','comparison_tasks','comparisons')]:
    task_inputs = {x['id']:x for x in source[input_key]}
    results = {x['id']:x for x in expected[output_key]}
    for n in typed(node_type):
        p = prop(n); case_id = p['case_id']; wanted = results[case_id]
        if node_type == 'IdentityCase':
            check({ 'id':case_id, 'union':p['candidate_union'], 'intersection':p['candidate_intersection'],
                    'action':p['action'], 'org_id':p['selected_org_id']} == wanted, 'Identity decision preserved')
            check(prop(one(n,'SELECTED'))['org_id'] == wanted['org_id'], 'Selected identity link')
            for key in ['mention','context','name_candidates','vector_candidates']:
                check(p[key] == task_inputs[case_id][key], 'Identity task input preserved')
        else:
            check({'id':case_id, 'decision':p['decision'], 'basis':p['basis']} == wanted,
                  'Comparison decision preserved')
            for side in ['left','right']:
                check({k:p[f'{side}_{k}'] for k in task_inputs[case_id][side]} == task_inputs[case_id][side],
                      'Comparison input preserved')
            check(not any(nodes[e['to']]['type']=='Idea' for e in outgoing[n['id']]),
                  'No diagnostic-to-extracted-Idea identity fabricated')
        run = one(n,'IN_RUN')
        batch_input = read(prop(run)['input_file'])
        check(case_id in {x['id'] for x in batch_input[input_key]}, 'Case linked to generating run')

for run in typed('ExtractionRun'):
    p = prop(run)
    for file_key, hash_key in [('raw_output_file','raw_output_sha256'),('input_file','input_sha256'),
                              ('submitted_file','submitted_sha256'),('prompt_file','prompt_sha256')]:
        check(hashlib.sha256((ROOT / p[file_key]).read_bytes()).hexdigest() == p[hash_key],
              'Run source hash matches')
    batch = read(p['raw_output_file'])
    for key in ['reports','identities','comparisons']:
        main = {x['id']:x for x in expected[key]}
        check(all(main[x['id']] == x for x in batch[key]), 'Combined output equals retained batch output')
    for process in typed('ProcessingRecord'):
        if one(process,'IN_RUN') == run:
            check(prop(process)['report_id'] in {x['id'] for x in batch['reports']}, 'Report run membership')

# Concrete owner-review scenarios beyond structural equality.
def expression(report_id, position=1):
    return next(n for n in linked(reports[report_id],'CONTAINS') if prop(n)['position']==position)

check(len(linked(expression('H08'),'HAS_JUDGMENT')) == 2, 'Joint pair stays one expression')
check(len(linked(reports['H17'],'CONTAINS')) == 2, 'Independent judgments stay separate')
check(len(linked(reports['H36'],'CONTAINS')) == 0, 'Insufficient report is still retained')
check(not linked(one(expression('H12'),'EXPRESSES'),'ABOUT_DOMAIN'), 'Unspecified domain stays unspecified')
check(prop(one(one(expression('H10'),'EXPRESSES'),'ABOUT_DOMAIN'))['name'] == 'SOFTWARE_TOOLS',
      'Extracted domain is not replaced by catalogue domain')
check(prop(one(expression('H31'),'EXPRESSES'))['summary'].find('unchanged') >= 0
      and not linked(expression('H31'),'HAS_JUDGMENT'), 'Flat forecast is not labelled no-forecast')
check(prop(reports['H01'])['available_on'] > prop(linked(expression('H01'),'HAS_JUDGMENT')[0])['start'],
      'Source availability does not overwrite forecast anchor')
check([rid for rid in ['H18','H19'] if prop(reports[rid])['available_on'] <= '2026-10-14'] == ['H18'],
      'Availability query preserves claim first, denial later')
check(len({prop(n)['source_id'] for n in typed('Person')
           if prop(n)['source_id'] in ['person:sel','person:selene']}) == 2, 'Anonymous identities stay separate')
check(not any(e['type'] in ['SUPPLIES','CAUSES','SAME_AS'] for e in g['edges']), 'No invented dependency or merge')

for category in ['source_files','projection_files']:
    for path, digest in manifest[category].items():
        check(hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest, ('File hash',path))
result = {'status':'PASS', 'checks_passed':checks, 'nodes':len(nodes), 'relationships':len(g['edges']),
    'report_output_roundtrip':'EXACT', 'evidence_quotes':42, 'cypher_engine_execution':'NOT_RUN',
    'scope':'Offline source fidelity, integrity, provenance and concrete review scenarios; no benchmark accuracy claim.'}
(ROOT/'validation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
