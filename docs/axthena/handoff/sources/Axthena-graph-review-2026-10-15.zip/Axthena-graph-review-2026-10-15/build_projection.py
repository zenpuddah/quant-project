"""Disposable review export, not Axthena production code. Python standard library only."""
from pathlib import Path
import collections
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence'
FIXTURE = 'axhard-a-20261015'
PREFIX = FIXTURE + '/'


def read(name):
    return json.loads((EVIDENCE / name).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


nodes, edges, by_id = [], [], {}


def node(node_type, key, **properties):
    identity = PREFIX + node_type + '/' + str(key)
    props = {'id': identity, 'fixture_id': FIXTURE, 'data_status': 'FICTIONAL', **properties}
    item = {'id': identity, 'type': node_type, 'properties': props}
    if identity in by_id:
        assert by_id[identity] == item, f'Conflicting node: {identity}'
    else:
        by_id[identity] = item
        nodes.append(item)
    return identity


def edge(source, kind, target, **properties):
    identity = PREFIX + 'edge/' + hashlib.sha256(
        encoded([source, kind, target]).encode()).hexdigest()[:24]
    item = {'id': identity, 'from': source, 'type': kind, 'to': target,
            'properties': {'id': identity, 'fixture_id': FIXTURE, **properties}}
    assert item not in edges, f'Duplicate relationship: {identity}'
    edges.append(item)


inputs = read('input.json')
outputs = read('combined_output_A.json')
original_manifest = read('run_manifest.json')
fixture = node('Fixture', FIXTURE, name='Axthena — fictional A graph review',
    purpose='Owner inspection of retained extraction output, not a production model selection',
    projection_version='1', idea_identity_scope='REPORT_LOCAL_SINGLETONS',
    time_scope='SOURCE_AVAILABILITY_ONLY; not historical fitted-model replay',
    temporary_test_conventions_json=encoded(inputs['temporary_test_conventions']),
    input_sha256=sha(EVIDENCE / 'input.json'),
    output_sha256=sha(EVIDENCE / 'combined_output_A.json'))

orgs, domains, stocks, sources, persons, paragraphs, runs, report_runs = {}, {}, {}, {}, {}, {}, {}, {}
case_runs = {}
for name in inputs['temporary_test_conventions']['domain_vocabulary']:
    if name is not None:
        domains[name] = node('Domain', name, name=name,
                             origin='SUPPLIED_FIXTURE_VOCABULARY')
for i, org in enumerate(inputs['organisations']):
    orgs[org['id']] = node('Organisation', org['id'], org_id=org['id'], name=org['name'],
        aliases=org['aliases'], origin='SUPPLIED_UNDATED_CATALOGUE',
        input_path=f'$.organisations[{i}]')
    edge(fixture, 'CATALOGUES', orgs[org['id']])
for org in inputs['organisations']:
    for domain in org['domains']:
        edge(orgs[org['id']], 'CATALOG_DOMAIN', domains[domain], basis='SUPPLIED_UNDATED_CATALOGUE')
    if org.get('parent'):
        edge(orgs[org['id']], 'SUBSIDIARY_OF', orgs[org['parent']], basis='SUPPLIED_UNDATED_CATALOGUE')
    if org['stock']:
        symbol = org['stock']
        stocks[symbol] = node('Stock', symbol, symbol=symbol, name=symbol,
                              origin='SUPPLIED_UNDATED_CATALOGUE')
        edge(stocks[symbol], 'ISSUED_BY', orgs[org['id']], basis='SUPPLIED_UNDATED_CATALOGUE')

# These are independent identity-task outcomes, not a replay of sequential ingestion.
for result in outputs['identities']:
    if result['org_id'] not in orgs:
        assert result['org_id'].startswith('NEW:')
        orgs[result['org_id']] = node('Organisation', result['org_id'],
            org_id=result['org_id'], name=result['org_id'][4:], aliases=[],
            origin='DECLARED_NEW_ID_IN_RETAINED_OUTPUT',
            identity_scope='SHARED_OUTPUT_IDENTIFIER; not evidence of sequential deduplication')

for run in original_manifest['runs']:
    if run['variant'] != 'A':
        continue
    k = run['batch']
    assert sha(EVIDENCE / run['raw_output_file']) == run['raw_output_sha256']
    assert sha(EVIDENCE / run['submitted_file']) == run['submitted_sha256']
    runs[k] = node('ExtractionRun', f'A{k}', name=f'A / batch {k}', batch=k, variant='A',
        worker=run['worker'], raw_output_file='evidence/' + run['raw_output_file'],
        raw_output_sha256=run['raw_output_sha256'], submitted_sha256=run['submitted_sha256'],
        submitted_file='evidence/' + run['submitted_file'],
        input_file='evidence/' + run['input_file'], input_sha256=sha(EVIDENCE / run['input_file']),
        prompt_file='evidence/prompt_A.txt', prompt_sha256=sha(EVIDENCE / 'prompt_A.txt'),
        experiment_recorded_at_utc=original_manifest['recorded_at_utc'],
        execution_time=None, model_snapshot=None, fitted_at=None,
        unknown_fields_reason=original_manifest['unknown_fields_reason'])
    edge(fixture, 'RETAINS_RUN', runs[k])
    batch_input = read(f'batch{k}/input.json')
    for report in batch_input['reports']:
        report_runs[report['id']] = k
    for task in batch_input['identity_tasks'] + batch_input['comparison_tasks']:
        case_runs[task['id']] = k

output_by_report = {r['id']: (i, r) for i, r in enumerate(outputs['reports'])}
for ri, report in enumerate(inputs['reports']):
    rid = report['id']
    oi, extracted = output_by_report[rid]
    run_id = runs[report_runs[rid]]
    sid = report['source_id']
    if sid not in sources:
        sources[sid] = node('Source', sid, source_id=sid, name=sid,
            source_type=report['source_type'], origin='SUPPLIED_FIXTURE_SOURCE_ID')
        if report['source_type'] == 'PERSON':
            persons[sid] = node('Person', sid, source_id=sid, name=sid,
                identity_scope='SOURCE_ID_ONLY; real-world identity not established')
            edge(sources[sid], 'IDENTIFIES_PERSON', persons[sid])
        elif report['source_type'] == 'COMPANY':
            edge(sources[sid], 'REPRESENTS', orgs[sid.split(':', 1)[1]],
                 basis='SUPPLIED_FIXTURE_SOURCE_ID')
    else:
        assert by_id[sources[sid]]['properties']['source_type'] == report['source_type']
    rnode = node('Report', rid, report_id=rid, name=rid,
        published_on=report['published_on'],
        first_supported_available_on=report['first_supported_available_on'],
        collected_on=report['collected_on'], available_on=extracted['available_on'],
        source_type=report['source_type'], source_id=sid, body_status=report['body_status'],
        confirmation_scope=report['confirmation_scope'],
        confirmation_scope_basis='SUPPLIED_INPUT; not independently verified',
        input_file='evidence/input.json', input_path=f'$.reports[{ri}]',
        original_url=None, original_url_status='FICTIONAL_NO_URL')
    edge(fixture, 'CONTAINS_REPORT', rnode)
    edge(rnode, 'PUBLISHED_IN', sources[sid])
    process = node('ProcessingRecord', rid, report_id=rid, name=f'{rid} processing',
        processing_status=extracted['processing_status'], cap_omitted=extracted['cap_omitted'],
        output_file='evidence/combined_output_A.json', output_path=f'$.reports[{oi}]',
        retained_idea_count=len(extracted['ideas']))
    edge(process, 'PROCESSED', rnode)
    edge(process, 'IN_RUN', run_id)
    for pi, paragraph in enumerate(report['paragraphs']):
        pnode = node('Paragraph', paragraph['id'], paragraph_id=paragraph['id'],
            name=paragraph['id'], position=pi + 1, text=paragraph['text'],
            text_sha256=hashlib.sha256(paragraph['text'].encode()).hexdigest(),
            input_path=f'$.reports[{ri}].paragraphs[{pi}]')
        paragraphs[paragraph['id']] = (pnode, paragraph['text'], rid)
        edge(rnode, 'HAS_PARAGRAPH', pnode, position=pi + 1)
    for ii, idea in enumerate(extracted['ideas']):
        ikey = f'{rid}.{ii + 1}'
        opath = f'$.reports[{oi}].ideas[{ii}]'
        expr = node('Expression', ikey, name=ikey, report_id=rid, position=ii + 1,
            kind=idea['kind'], event_phase=idea['event_phase'],
            output_path=opath, output_file='evidence/combined_output_A.json',
            judgment_status=('HAS_RETAINED_UP_DOWN' if idea['judgments'] else 'NO_RETAINED_UP_DOWN'))
        inode = node('Idea', ikey, name=ikey, summary=idea['summary'],
            identity_scope='REPORT_LOCAL_SINGLETON', output_path=opath,
            domain_state='UNSPECIFIED' if idea['domain'] is None else 'EXTRACTED')
        edge(rnode, 'CONTAINS', expr)
        edge(process, 'PRODUCED', expr)
        edge(expr, 'EXPRESSES', inode)
        edge(expr, 'ATTRIBUTED_TO', sources[sid])
        if sid in persons:
            edge(expr, 'EXPRESSED_BY', persons[sid])
        for org_id in idea['org_ids']:
            edge(inode, 'CONCERNS', orgs[org_id], basis='RETAINED_EXTRACTION')
        if idea['domain'] is not None:
            edge(inode, 'ABOUT_DOMAIN', domains[idea['domain']],
                 basis='EXTRACTED_IDEA_DOMAIN; no per-organisation assignment inferred')
        for ji, judgment in enumerate(idea['judgments']):
            jnode = node('Judgment', f'{ikey}.j{ji + 1}',
                name=f"{judgment['stock']} {judgment['direction']}", **judgment,
                position=ji + 1, output_path=f'{opath}.judgments[{ji}]',
                qualification_location='PARENT_IDEA_SUMMARY_AND_EVIDENCE',
                end_boundary='EXCLUSIVE_TRIAL_CONVENTION')
            edge(expr, 'HAS_JUDGMENT', jnode)
            edge(jnode, 'TARGETS', stocks[judgment['stock']])
        for ei, evidence in enumerate(idea['evidence']):
            pnode, text, parent_report = paragraphs[evidence['paragraph_id']]
            quote = evidence['quote']
            assert parent_report == rid
            assert text.count(quote) == 1, f'Absent or ambiguous span: {ikey}'
            start = text.index(quote)
            stop = start + len(quote)
            enode = node('Passage', f'{ikey}.e{ei + 1}', name=f'{ikey} evidence {ei + 1}',
                quote=quote, paragraph_id=evidence['paragraph_id'], position=ei + 1,
                start_codepoint=start, end_codepoint=stop,
                start_utf8_byte=len(text[:start].encode()), end_utf8_byte=len(text[:stop].encode()),
                offset_convention='ZERO_BASED_END_EXCLUSIVE', output_path=f'{opath}.evidence[{ei}]')
            edge(expr, 'SUPPORTED_BY', enode)
            edge(enode, 'FROM_PARAGRAPH', pnode)

identity_inputs = {t['id']: t for t in inputs['identity_tasks']}
for i, result in enumerate(outputs['identities']):
    task = identity_inputs[result['id']]
    n = node('IdentityCase', result['id'], name=result['id'], case_id=result['id'],
        mention=task['mention'], context=task['context'], name_candidates=task['name_candidates'],
        vector_candidates=task['vector_candidates'], candidate_union=result['union'],
        candidate_intersection=result['intersection'], action=result['action'],
        selected_org_id=result['org_id'], output_path=f'$.identities[{i}]',
        task_scope='INDEPENDENT_DIAGNOSTIC; candidate lists supplied, not computed by this projection')
    edge(fixture, 'HAS_IDENTITY_CASE', n)
    edge(n, 'SELECTED', orgs[result['org_id']])
    edge(n, 'IN_RUN', runs[case_runs[result['id']]])

comparison_inputs = {t['id']: t for t in inputs['comparison_tasks']}
for i, result in enumerate(outputs['comparisons']):
    task = comparison_inputs[result['id']]
    properties = {'case_id': result['id'], 'name': result['id'], 'decision': result['decision'],
                  'basis': result['basis'], 'output_path': f'$.comparisons[{i}]',
                  'task_scope': 'INDEPENDENT_PAIR; no extracted-Idea foreign keys or merges'}
    for side in ['left', 'right']:
        for key, value in task[side].items():
            properties[f'{side}_{key}'] = value
    n = node('ComparisonCase', result['id'], **properties)
    edge(fixture, 'HAS_COMPARISON_CASE', n)
    edge(n, 'IN_RUN', runs[case_runs[result['id']]])

assert len(by_id) == len(nodes)
assert len({e['id'] for e in edges}) == len(edges)
assert all(e['from'] in by_id and e['to'] in by_id for e in edges)
graph = {'fixture_id': FIXTURE, 'data_status': 'FICTIONAL', 'nodes': nodes, 'edges': edges}
dump(ROOT / 'graph.json', graph)


def cypher(value):
    if isinstance(value, dict):
        assert all(re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*', k) for k in value)
        return '{' + ', '.join('`' + k + '`: ' + cypher(v) for k, v in value.items()) + '}'
    if isinstance(value, list):
        return '[' + ', '.join(cypher(v) for v in value) + ']'
    return json.dumps(value, ensure_ascii=False)


lines = [
    '// DISPOSABLE FICTIONAL REVIEW DATA. One Cypher statement; no APOC or external URLs.',
    '// Uses AxHardReview and namespaced IDs. Does not reset or alter earlier fixtures.',
    '// Run once at a time. Same-file reruns use MERGE; concurrent loading is not supported.',
    '// Null JSON values become absent Neo4j properties (Cypher reads them as null).',
    'WITH [\n' + ',\n'.join(cypher(n) for n in nodes) + '\n] AS nodes,',
    '[\n' + ',\n'.join(cypher(e) for e in edges) + '\n] AS edges',
]
for kind in sorted({n['type'] for n in nodes}):
    assert re.fullmatch(r'[A-Za-z]+', kind)
    lines.extend([
        f'FOREACH (row IN [item IN nodes WHERE item.type = "{kind}"] |',
        f'  MERGE (n:AxHardReview:{kind} {{id: row.id}})',
        '  SET n += row.properties',
        ')',
    ])
for kind in sorted({e['type'] for e in edges}):
    assert re.fullmatch(r'[A-Z_]+', kind)
    lines.extend([
        f'FOREACH (row IN [item IN edges WHERE item.type = "{kind}"] |',
        '  MERGE (a:AxHardReview {id: row.from})',
        '  MERGE (b:AxHardReview {id: row.to})',
        f'  MERGE (a)-[r:{kind} {{id: row.id}}]->(b)',
        '  SET r += row.properties',
        ')',
    ])
lines.append('RETURN size(nodes) AS fixture_node_rows, size(edges) AS fixture_relationship_rows;')
(ROOT / 'load.cypher').write_text('\n'.join(lines) + '\n', encoding='utf-8')

manifest = {
    'fixture_id': FIXTURE, 'data_status': 'FICTIONAL', 'projection_created_on': '2026-10-15',
    'new_model_execution': False, 'production_database_selected': False,
    'graph_counts': dict(sorted(collections.Counter(n['type'] for n in nodes).items())),
    'total_nodes': len(nodes), 'total_relationships': len(edges),
    'source_files': {str(p.relative_to(ROOT)): sha(p) for p in sorted(EVIDENCE.rglob('*')) if p.is_file()},
    'projection_files': {p.name: sha(p) for p in [ROOT / 'graph.json', ROOT / 'load.cypher', ROOT / 'build_projection.py']},
    'database_execution': 'NOT_EXECUTED',
    'limits': ['No canonical cross-report Idea merging performed.',
               'No structured Event/Fact/Confirmation/dependency records were emitted by this extraction.',
               'No historical model-state replay or performance benchmark.',
               'Identity candidate lists were supplied; retrieval filters were not executed.',
               'Twelve-month real-source coverage is a separate, unselected acquisition step.'],
}
dump(ROOT / 'projection_manifest.json', manifest)
print(json.dumps({k: manifest[k] for k in ['graph_counts', 'total_nodes', 'total_relationships']}, indent=2))
