# Axthena ChatGPT instruction pilot — 15 October 2026

All reports are fictional. This packet preserves an executed in-session assistant-worker trial, not an independently verified ordinary ChatGPT UI/model benchmark. No external LLM API is used by any script here. Product implementation is not included.

Start with the report `Axthena-ChatGPT-trial-2026-10-15.md` and `semantic_review.md`.

- `chat_copy_A.txt`, `chat_copy_B.txt`, `chat_copy_C.txt`: standalone prompts including identical source packets; copy one into a fresh chat for a new, separately recorded run.
- `prompt_A/B/C.txt`: instruction-only versions.
- `input.json`: 17 fictional reports, five identity tasks, 14 meaning comparisons.
- `reference.json`: assistant-authored, pre-run-reviewed labels; not owner-validated gold.
- `output_A/B/C.json`: unchanged model-authored outputs from three fresh worker contexts.
- `freeze_manifest.json`, `run_manifest.json`: hashes and known/unknown execution metadata.
- `output_schema.json`: experimental output shape, not a production decision.
- `scores.json`: exact structured checks, quote checks and derived evidence offsets.
- `semantic_review.md`: separate assistant review, including the C/R06 wording issue.
- `scorer_selfcheck.json`: deliberately corrupted examples were detected; these are not extra model runs.
- `query_examples.json`: five illustrative reads of A's retained output, awaiting owner review.

With Python 3, run from this directory:

```sh
python3 score.py
python3 query_examples.py
```

These scripts use the standard library, make no network/model calls and reproduce local scoring only. The shape checker supports the subset emitted in this packet, not every JSON Schema feature. Fresh ChatGPT generation is not promised to reproduce the saved responses.

All variants tied on the mechanical reference checks; C had a minor summary ambiguity. Results are one-shot diagnostics on short, explicit, synthetic text. Real-news accuracy, provider superiority, speed and cost were not measured. Exact runtime model and sampling settings were not exposed.

The date boundary, missing-duration handling, diagnostic comparison label and schema are temporary experiment conventions. Existing C++ plans, Cypher fixtures and live graph are unchanged.
