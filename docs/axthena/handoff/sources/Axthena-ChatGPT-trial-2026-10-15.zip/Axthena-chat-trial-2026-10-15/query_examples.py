"""Illustrative reads over retained JSON, not the production query interface."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
packet=json.loads((ROOT/'input.json').read_text())
out=json.loads((ROOT/'output_A.json').read_text())
sources={r['id']:r for r in packet['reports']}
rows=[{'report_id':r['id'],'idea_index':n,'source_id':sources[r['id']]['source_id'],'available_on':r['available_on'],'processing_status':r['processing_status'],**i} for r in out['reports'] for n,i in enumerate(r['ideas'])]
up=[{'report_id':r['report_id'],'source_id':r['source_id'],'judgments':[j for j in r['judgments'] if j['stock']=='NOVA' and j['direction']=='UP']} for r in rows if r['available_on']<='2026-10-05' and any(j['stock']=='NOVA' and j['direction']=='UP' for j in r['judgments'])]
joint=[{'report_id':r['report_id'],'idea_index':r['idea_index'],'org_ids':r['org_ids'],'judgments':r['judgments']} for r in rows if {j['stock'] for j in r['judgments']}=={'NOVA','DRAG'}]
subs=[{'report_id':r['report_id'],'org_ids':r['org_ids'],'domain':r['domain']} for r in rows if 'O3' in r['org_ids']]
production=[{'report_id':r['report_id'],'event_phase':r['event_phase'],'summary':r['summary']} for r in rows if r['available_on']<='2026-10-08' and r['report_id'] in ['R08','R09']]
partial=[{'report_id':r['id'],'processing_status':r['processing_status'],'idea_count':len(r['ideas'])} for r in out['reports'] if r['processing_status']!='COMPLETE']
checks=[
 {'question':'Which NOVA UP statements have supported source availability by 5 October?','result':up,'expected_report_ids':['R02','R05','R14','R16'],'pass':[r['report_id'] for r in up]==['R02','R05','R14','R16']},
 {'question':'Which single Idea carries both NOVA and DRAG judgments?','result':joint,'expected_report_ids':['R05'],'pass':[r['report_id'] for r in joint]==['R05']},
 {'question':'Which Ideas directly concern NovaCloud rather than automatically its parent?','result':subs,'expected_report_ids':['R12'],'pass':len(subs)==1 and subs[0]['org_ids']==['O3']},
 {'question':'What N2 production information is source-available by 8 October?','result':production,'expected':'R08 announcement only; R09 actual start is later.','pass':len(production)==1 and production[0]['report_id']=='R08' and production[0]['event_phase']=='ANNOUNCEMENT'},
 {'question':'Which reports have partial or insufficient processing?','result':partial,'expected_report_ids':['R10','R11'],'pass':[r['report_id'] for r in partial]==['R10','R11']}]
assert all(c['pass'] for c in checks)
(ROOT/'query_examples.json').write_text(json.dumps({'status':'Illustrative offline reads; expected answers authored by assistant, awaiting owner review. Source-time filtering is retrospective, not proof of operational availability or historical fitted models.','checks':checks},ensure_ascii=False,indent=2)+'\n')
print('Five illustrative reads agree with their stated expected answers.')
