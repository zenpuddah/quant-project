"""Offline diagnostic scorer. No model/API calls. Run: python3 score.py.
Exact field agreement is not semantic support or real-world accuracy.
"""
import copy
import hashlib
import json
import re
from pathlib import Path
from collections import Counter

ROOT=Path(__file__).resolve().parent
def read(name): return json.loads((ROOT/name).read_text(encoding='utf-8'))
def save(name,value): (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
packet=read('input.json'); reference=read('reference.json')
paragraphs={p['id']:p['text'] for r in packet['reports'] for p in r['paragraphs']}
def obj(properties,required=None):
 return {'type':'object','properties':properties,'required':required or list(properties),'additionalProperties':False}
def arr(items): return {'type':'array','items':items}
def enum(*values): return {'enum':list(values)}
text={'type':'string','minLength':1}
date={'anyOf':[{'type':'string','pattern':r'^\d{4}-\d{2}-\d{2}$'},{'type':'null'}]}
ids={'type':'array','items':text,'uniqueItems':True}
judgment=obj({'stock':enum('NOVA','DRAG'),'direction':enum('UP','DOWN'),'window_state':enum('EXPLICIT','RELATIVE','MISSING'),'start':date,'end':date})
evidence=obj({'paragraph_id':text,'quote':text})
idea=obj({'summary':text,'org_ids':{**ids,'minItems':1},'domain':enum(*packet['temporary_test_conventions']['domain_vocabulary']),'kind':enum('FACT','CONFIRMED_NEWS','RUMOURED_NEWS','OPINION'),'event_phase':enum('ANNOUNCEMENT','OCCURRED','POTENTIAL','NONE'),'judgments':arr(judgment),'evidence':{**arr(evidence),'minItems':1}})
report=obj({'id':text,'available_on':{'type':'string','pattern':r'^\d{4}-\d{2}-\d{2}$'},'processing_status':enum('COMPLETE','PARTIAL','INSUFFICIENT'),'cap_omitted':{'type':'boolean'},'ideas':{**arr(idea),'maxItems':2}})
schema=obj({'reports':arr(report),'identities':arr(obj({'id':text,'union':ids,'intersection':ids,'action':enum('REUSE','CREATE'),'org_id':text})),'comparisons':arr(obj({'id':text,'decision':enum('SAME','DIFFERENT','INSUFFICIENT'),'basis':text}))})

def shape_errors(value, rule, path=''):
 """Check only the documented subset emitted above; not a general JSON Schema engine."""
 errors=[]
 def error(message):errors.append({'path':path,'message':message})
 supported={'type','properties','required','additionalProperties','items','enum','minLength','pattern','anyOf','uniqueItems','minItems','maxItems'}
 assert not (set(rule)-supported), f'Unsupported schema keyword: {set(rule)-supported}'
 if 'anyOf' in rule:
  if all(shape_errors(value,r,path) for r in rule['anyOf']):error('No allowed shape matches')
  return errors
 if 'enum' in rule and value not in rule['enum']:error('Value outside allowed enumeration')
 typ=rule.get('type')
 types={'object':dict,'array':list,'string':str,'boolean':bool,'null':type(None)}
 if typ and not isinstance(value,types[typ]):error('Expected '+typ);return errors
 if typ=='object':
  for k in rule.get('required',[]):
   if k not in value:error('Missing required field '+k)
  props=rule.get('properties',{})
  for k,v in value.items():
   if k not in props:
    if rule.get('additionalProperties') is False:error('Unexpected field '+k)
   else:errors.extend(shape_errors(v,props[k],path+'/'+k))
 if typ=='array':
  if len(value)<rule.get('minItems',0):error('Too few items')
  if len(value)>rule.get('maxItems',float('inf')):error('Too many items')
  if rule.get('uniqueItems') and len({json.dumps(x,sort_keys=True) for x in value})!=len(value):error('Duplicate list item')
  for i,v in enumerate(value):errors.extend(shape_errors(v,rule['items'],path+'/'+str(i)))
 if typ=='string':
  if len(value)<rule.get('minLength',0):error('String too short')
  if 'pattern' in rule and re.search(rule['pattern'],value) is None:error('String pattern mismatch')
 return errors

def evaluate(output):
 errors=[];checks=[];spans=[];report_passes={}
 schema_errors=shape_errors(output,schema)
 def check(category,path,actual,expected):
  ok=actual==expected
  checks.append({'category':category,'path':path,'pass':ok})
  if not ok:errors.append({'category':category,'path':path,'actual':actual,'expected':expected})
  return ok
 indexes={}
 for group in ['reports','identities','comparisons']:
  values=output.get(group,[]) if isinstance(output,dict) else []
  values=values if isinstance(values,list) else []
  got_ids=[x.get('id') for x in values if isinstance(x,dict)]
  want_ids=[x['id'] for x in reference[group]]
  check('inventory',group,Counter(got_ids),Counter(want_ids))
  indexes[group]={x.get('id'):x for x in values if isinstance(x,dict)}
 for want in reference['reports']:
  rid=want['id'];got=indexes['reports'].get(rid,{})
  before=len(errors)
  for k in ['available_on','processing_status','cap_omitted']:
   check('report_metadata',f'{rid}.{k}',got.get(k),want[k])
  gotideas=got.get('ideas',[])
  if not isinstance(gotideas,list):gotideas=[]
  check('idea_count',rid,len(gotideas),len(want['ideas']))
  for n,wi in enumerate(want['ideas']):
   gi=gotideas[n] if n<len(gotideas) and isinstance(gotideas[n],dict) else {}
   prefix=f'{rid}.ideas[{n}]'
   for k in ['org_ids','domain','kind','event_phase']:
    a=gi.get(k);b=wi[k]
    if k=='org_ids': a=sorted(a) if isinstance(a,list) else a;b=sorted(b)
    check('idea_fields',prefix+'.'+k,a,b)
   actual_j=gi.get('judgments')
   norm=lambda value:sorted(value,key=lambda j:json.dumps(j,sort_keys=True)) if isinstance(value,list) else value
   check('judgment_records',prefix+'.judgments',norm(actual_j),norm(wi['judgments']))
   evs=gi.get('evidence',[])
   if not isinstance(evs,list):evs=[]
   valid=[]
   for q,ev in enumerate(evs):
    p=ev.get('paragraph_id');quote=ev.get('quote');source=paragraphs.get(p,'')
    ok=isinstance(quote,str) and bool(quote) and p in paragraphs and quote in source and p.startswith(rid+'.')
    check('quote_integrity',f'{prefix}.evidence[{q}]',ok,True)
    if ok:
     valid.append(p);start=source.index(quote);end=start+len(quote)
     spans.append({'report_id':rid,'idea_index':n,'paragraph_id':p,'quote':quote,'occurrences':source.count(quote),'codepoint_start':start,'codepoint_end_exclusive':end,'utf8_byte_start':len(source[:start].encode()),'utf8_byte_end_exclusive':len(source[:end].encode())})
   check('evidence_coverage',prefix+'.evidence',bool(set(valid)&set(wi['evidence_any_of'])),True)
  report_passes[rid]=len(errors)==before
 for want in reference['identities']:
  got=indexes['identities'].get(want['id'],{})
  for k in ['union','intersection','action','org_id']:
   a=got.get(k);b=want[k]
   if k in ['union','intersection']:a=sorted(a) if isinstance(a,list) else a;b=sorted(b)
   check('identity',want['id']+'.'+k,a,b)
 for want in reference['comparisons']:
  check('comparison',want['id'],indexes['comparisons'].get(want['id'],{}).get('decision'),want['decision'])
 categories={}
 for c in checks:
  m=categories.setdefault(c['category'],{'passed':0,'total':0});m['total']+=1;m['passed']+=int(c['pass'])
 proposed_same=[x['id'] for x in output.get('comparisons',[]) if x.get('decision')=='SAME']
 expected_same={x['id'] for x in reference['comparisons'] if x['decision']=='SAME'}
 false_merges=[i for i in proposed_same if i not in expected_same]
 return {'schema_valid':not schema_errors,'schema_errors':schema_errors,'categories':categories,'report_records_matching_reference':{'passed':sum(report_passes.values()),'total':len(report_passes)},'report_passes':report_passes,'comparison_same':{'proposed':len(proposed_same),'correct':sum(i in expected_same for i in proposed_same),'reference_total':len(expected_same),'false_merges':false_merges},'errors':errors,'evidence_spans':spans}

def main():
 frozen=read('freeze_manifest.json')
 for name,wanted_hash in frozen['files'].items():
  assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==wanted_hash, f'Frozen file changed: {name}'
 save('output_schema.json',schema)
 results={};raw={}
 for label in 'ABC':
  path=ROOT/f'output_{label}.json'
  try:raw[label]=json.loads(path.read_text());result=evaluate(raw[label])
  except Exception as e:result={'parse_or_scoring_error':type(e).__name__+': '+str(e)}
  result['raw_sha256']=hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
  result['prompt_words']=len((ROOT/f'prompt_{label}.txt').read_text().split())
  result['raw_output_bytes']=path.stat().st_size if path.exists() else None
  results[label]=result
 save('scores.json',results)
 # Detection checks: mutations of retained output are never counted as model runs.
 tests=[]
 if 'A' in raw:
  base=evaluate(raw['A'])
  x=copy.deepcopy(raw['A']);next(r for r in x['reports'] if r['id']=='R01')['ideas'][0]['judgments']=[{'stock':'NOVA','direction':'UP','window_state':'MISSING','start':None,'end':None}]
  tests.append({'test':'invented_price_forecast_detected','pass':any(e['path']=='R01.ideas[0].judgments' for e in evaluate(x)['errors'])})
  x=copy.deepcopy(raw['A']);next(c for c in x['comparisons'] if c['id']=='M02')['decision']='SAME'
  tests.append({'test':'different_window_false_merge_detected','pass':'M02' in evaluate(x)['comparison_same']['false_merges']})
  x=copy.deepcopy(raw['A']);next(r for r in x['reports'] if r['id']=='R15')['ideas'][0]['evidence'][0]['quote']='INVENTED SOURCE WORDS'
  tests.append({'test':'invented_unicode_passage_detected','pass':any(e['category']=='quote_integrity' and e['path'].startswith('R15.') for e in evaluate(x)['errors'])})
  x=copy.deepcopy(raw['A']);x['reports'].append(copy.deepcopy(x['reports'][0]))
  tests.append({'test':'duplicate_report_detected','pass':any(e['category']=='inventory' for e in evaluate(x)['errors'])})
 assert all(x['pass'] for x in tests)
 save('scorer_selfcheck.json',{'status':'Artificial mutation checks; not model trials','checks':tests})
 print(json.dumps({k:{q:v[q] for q in ['schema_valid','categories','report_records_matching_reference','comparison_same','errors','prompt_words'] if q in v} for k,v in results.items()},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
