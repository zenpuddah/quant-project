# Independent semantic review — batch 2

Reviewed only `batch2/input.json`, `batch2/output_A.json`, `batch2/output_B.json`, `batch2/output_C.json`, and `prompt_A.txt`. No reference answers, scores, author notes, or other prompt variants were read. Outputs were not rewritten.

No material source-meaning defect or erroneous comparison decision/basis was found in this review. This is a finding on this finite packet, not a calibrated accuracy estimate. Several summaries contain source-supported clauses that are not expressly reproduced in their selected quotations; those are identified separately below and are **not** failures of the requirement to supply at least one exact quote per Idea.

## Denominators and method

| Variant | Reports inspected | Retained summaries inspected | Selected quotations inspected | Stock judgments inspected | Comparison decisions and bases inspected | Identity tasks inspected |
|---|---:|---:|---:|---:|---:|---:|
| A | 12 | 13 | 14 | 3 | 12 | 4 |
| B | 12 | 13 | 14 | 3 | 12 | 4 |
| C | 12 | 13 | 19 | 3 | 12 | 4 |
| Total | 36 | 39 | 47 | 9 | 36 | 12 |

Every retained summary and each selected quote were compared with its report's paragraphs and supplied confirmation scope. An exact-substring check also verified all 47 quotations against their named source paragraph. All 39 Ideas have at least one exact contiguous quote. No non-exact quote, wrong paragraph attribution, or missing required quote was found.

The meaningful distinctions inspected include announcement/completion, unfulfilled consent, corrected figures and denominators, installed capacity/realised output, unconfirmed past-event claims, denial, subsidiary/parent and supplier/customer scope, conditional and relative stock forecasts, actual forecast windows, and future service availability. Optional price details and every background sentence were not treated as mandatory summary content.

## Per-case semantic results

Each cell covers that variant's complete summary, selected evidence, and material fields. “No material defect” does not assert that the selected quotation alone reproduces every summary clause.

| Report / Idea | Variant A | Variant B | Variant C |
|---|---|---|---|
| H13 acquisition announcement | No material defect. “Closing was expected … subject to the largest customer's consent; completion was not confirmed” preserves the unfulfilled condition and announcement stage. | No material defect. “Closing is expected … remains conditional on customer consent” preserves the condition; omitting “largest” does not alter the main claim. | No material defect. Expected closing, customer-consent condition, and absence of confirmed completion are explicit. |
| H14 acquisition completion | No material defect. Completion on 14 October after consent, payment, assets, and employees agree with H14.p1. | No material defect. “Specified assets and engineering team” is a faithful compression of design files, patents, and the covered team. | No material defect. Completed transfer is distinguished from the earlier announcement. |
| H15 corrected hosting costs | No material defect. Corrected 9%, withdrawn 19%, per-active-tenant denominator, preceding-quarter baseline, and subsidiary cloud scope are retained. | No material defect; same material distinctions retained. | No material defect; same material distinctions retained. |
| H16 F8 operation/capacity | No material defect. Commercial start/first paid batch are actual events; “installed capacity … does not establish realised monthly output” avoids converting capacity into production. | No material defect. Capacity is expressly distinguished from realised output. | No material defect. Full quote also includes the one-shift start and output contingencies. |
| H17 NOVA forecast | No material defect. Conditional certification on 19 October and 20 October–3 November window retained. Additional delayed-decision clause has explicit source support outside the selected quote; see diagnostic A1. | No material defect. Scheduled certification and budgeted-order mechanism are retained and quoted. | No material defect. Both the forecast condition and the delayed-decision qualification are quoted. |
| H17 DRAG forecast | No material defect. Independent cooling-revision concern and cash-generation rationale are supported by H17.p2. The selected quote covers the forecast/cooling gate but not all added rationale; see A2. | No material defect. Separate concern and cash-generation delay are quoted. | No material defect. The independent basis is explicitly quoted; omitting the cash-generation background is acceptable. |
| H18 alleged production start | No material defect. “Sources claim … began” plus RUMOURED_NEWS preserves an alleged past event. OCCURRED describes the claimed event stage, not confirmation certainty. Manufacturing is not promoted to shipment. See A3 for quote-only coverage. | No material defect. Unconfirmed account, alleged past start, manufacturing scope, lack of shipment notice, and no company response are preserved and quoted. | No material defect. Same distinctions; each additional summary clause has direct quoted support. |
| H19 denial of commercial start | No material defect. Negation, end-of-14-October cutoff, engineering samples, and absence of customer production orders retained. FACT/NONE is consistent with the signed denial. | No material defect; same. | No material defect; same. |
| H20 Relay launch | No material defect. Actual general availability on 11 October after a trial; trial-user continuity retained. O3/CLOUD_SOFTWARE avoids transferring this subsidiary activity to the parent. | No material defect; same. | No material defect; same. |
| H21 relative stock view | No material defect. NOVA outperforming DRAG is kept relative, sector downside remains possible, and judgments is empty. | No material defect. “Allows the whole sector to lose value” compresses a source example of downside risk without asserting that a decline is certain; quote retains the budget-tightening qualification. | No material defect. Relative forecast retained, no absolute direction invented; the selected quote retains the budget-tightening qualification. |
| H22 undated NOVA decline | No material defect. DOWN/MISSING/null dates correctly retain the direction without inventing a period. “May be needed” slightly softens “I think … will need” in the explanatory opinion, but does not change the retained stock direction or introduce a new condition. | No material defect. Same minor explanatory softening as A; direction and absent period are intact. | No material defect. “Believing further … revisions are needed” closely preserves the source's belief and undated direction. |
| H23 corrected solvent shipments | No material defect. 480 tonnes replaces 840; all customers and Ridge Materials' own shipments are retained, with no transfer to ForgeFoundry's output. See scope-coverage note below. | No material defect; same. | No material defect. Separate quotation expressly supports the exclusion of customer consumption/output. |
| H24 Harbor trial plan | No material defect. Confirms an announcement and planned date only; future opening is not asserted as completed. Final checks govern invitations, which this summary does not independently assert will be sent. | No material defect. Announcement/planned date and current unavailability retained. The quote also includes the final-check gate on invitations. | No material defect. Announcement/planned date and current unavailability retained. Omitting the invitation workflow is not an unsupported promise of trial execution. |

## Case-specific evidence-completeness diagnostics

These are **low-severity traceability observations**, not material extraction defects and not violations of the at-least-one-quote rule. The full input supports the summary text in each case.

### Variant A

- **A1 — H17, NOVA Idea: explicit delayed-decision sentence is outside the selected quote.** Output: “a delayed decision would remove the stated basis for the position.” Selected quote ends with “if the N7 AI chip receives its scheduled customer certification on 19 October.” The source continues: “My forecast depends on that approval arriving on schedule. A delayed decision would leave me without the same basis for taking the position”. The selected conditional provides substantial support, but a reader wanting the express delayed-decision qualification must consult the full paragraph. There is no erased condition and no invented summary fact.
- **A2 — H17, DRAG Idea: cash conversion and explicit independence are outside the selected quote.** Output: “Leni independently expects … delaying the conversion of finished inventory into cash.” Selected quote: “I expect DRAG shares to fall over the next ten days because its new AI-chip board still needs a cooling revision before the largest customer can accept deliveries.” H17.p2 additionally says “it postpones the point at which finished inventory can generate cash” and “This is a view about DragonLogic's own delivery problem, which I would hold even if the NovaChips certification decision went smoothly.” Both summary clauses are source-faithful; their express supporting sentences are simply not selected.
- **A3 — H18: absence of company confirmation is not independently established by the chosen source snippets.** Output: the account “lacks company confirmation”. The selected first quote attributes the claim to “two people familiar with the site”; the second covers missing ledger/shipment evidence. H18.p1 separately says “DragonLogic did not respond to the Monitor's request for comment before publication,” and the supplied confirmation scope is empty. The output's certainty is faithful; the chosen snippets do not themselves explicitly reproduce the no-response evidence. RUMOURED_NEWS/OCCURRED is correct for this claimed past event.

### Variants A and B: H23 scope-coverage note

Both summarize shipments as “not customer consumption or wafer output.” Their selected quote establishes “Ridge Materials shipped 480 tonnes” and “The total covers deliveries to all customers,” which already identifies the metric and scope. The direct exclusion sentence—“Customer consumption and wafer output are recorded in customers' own operating reports and are outside this dispatch summary”—is elsewhere in H23.p1 and is additionally selected by C. This is a **non-defect documentation opportunity**, not an unsupported interpretation or a missing-quote violation: shipments and customers' output are different metrics, and no output amount is invented.

### Variant B

No additional case-specific material defect or quote-completeness concern beyond the H23 scope note was found. In particular, B's expanded H17 quotations include the mechanism/independence context that A leaves in the full paragraph.

### Variant C

No case-specific material defect or substantive quote-completeness gap was found. Its H17, H18, H23, and H24 evidence selections explicitly cover the additional clauses discussed above. Publication year, availability date, confirmation status, and other packet metadata need not be restated inside a body-text quotation to be usable.

## Every comparison decision and basis

The decisions are identical across A, B, and C. Each variant's basis was read separately; the table records the source distinction or equivalence supporting all three bases.

| Comparison | A / B / C decision | Source meaning checked against every basis | Finding |
|---|---|---|---|
| HM13 | SAME | Both announced Kestrel agreement, required customer consent, and expected 14 October completion. | No defect; announcement is not treated as completion. |
| HM14 | SAME | Both withdraw 19% and replace it with 9% for NovaCloud's third-quarter hosting cost per active tenant. | No defect. A's shorter basis says “hosting cost reduction,” but does not replace the per-tenant metric with a different one. |
| HM15 | SAME | Both condition NOVA UP and DRAG DOWN on the shared order moving to NovaChips; both have the actual 20 October–3 November window. | No defect; order and wording differences do not split equal meaning. |
| HM16 | DIFFERENT | Left “announced its agreement”; right “completed its acquisition.” | No defect; event stage is the stated supported distinction. |
| HM17 | DIFFERENT | Engineering samples versus beginning commercial production at the same plant/date. | No defect; shared product, place, and date do not erase production status. |
| HM18 | DIFFERENT | NovaCloud's cloud-software hosting costs versus NovaChips' own AI-chip manufacturing costs. | No defect; organisation and operating scope differ. |
| HM19 | DIFFERENT | Left “may begin … according to an unconfirmed account”; right “confirmed … began”. | No defect; both possibility/event modality and confirmation differ. Crucially, this is not H18's unconfirmed allegation that production already began. |
| HM20 | DIFFERENT | “If” certification occurs versus “even if” certification does not occur, with the same dates. | No defect; a sufficient condition is not equated with a forecast that survives its absence. |
| HM21 | DIFFERENT | Relative NOVA-versus-DRAG outperformance versus absolute NOVA increase. | No defect; relative performance does not establish an absolute direction. |
| HM22 | DIFFERENT | Same words/rationale, but actual windows are 15–25 October and 16–26 October. | No defect; matching durations do not erase distinct dates. |
| HM23 | DIFFERENT | 9% versus 19% for the same NovaCloud cost-per-active-tenant metric, quarter, and baseline. | No defect; none of the bases treat the figures as interchangeable. |
| HM24 | INSUFFICIENT | Same text, but the left has no window and the right has 13–27 October. | No defect; missing dates are not assumed equal to known dates. |

## Additional field checks

All three variants preserve each report once, the appropriate organisation/domain scope, first-supported availability dates, and the three supported stock judgments. H17's relative ten-day DRAG period is 15–25 October under the supplied convention, not anchored to collection. H22 retains null dates. H21 supplies no absolute stock judgment. H13/H24 use ANNOUNCEMENT, H18 retains RUMOURED_NEWS with a claimed OCCURRED event, and H19 uses NONE for the denial.

The four identity tasks in each variant have the supplied union/intersection and supported decisions: HE05 reuses O3 despite O1 being the intersection; HE06 reuses O1 from the union despite O2 being the intersection; HE07 creates NEW:RidgeCompute; HE08 reuses O4 despite O5 being the intersection. These checks did not reveal a semantic scope error.

No blocking, high-severity, or moderate-severity semantic defect was identified. The low-severity observations above concern auditability of already-supported summary clauses, not fabricated content, inaccurate event stage, incorrect denominators, or a breach of the exact-quote minimum.
