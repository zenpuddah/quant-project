# Hard shard 1 author review

Independently authored synthetic data; no candidate model execution or candidate-output inspection. The baseline prompt, input schema and reference shape were the only source materials used. All company events and market claims are fictional.

## Composition

- 12 reports (H01–H12): six articles of 150–250 words and six shorter pieces of 60–130 words.
- 4 identity tasks (HE01–HE04): three REUSE, one CREATE.
- 12 comparisons (HM01–HM12): three SAME, eight DIFFERENT, one INSUFFICIENT.
- 13 expected Ideas: H06 has two; the other reports have one. All bodies are COMPLETE; none uses the cap.
- Exact structured output contract and allowed domain vocabulary are unchanged. Gold adds optional semantic_checks only.

| Report | Words | Primary challenge |
|---|---:|---|
| H01 | 171 | Compound conditional UP forecast; year crossing; publication differs from first supported availability and collection. |
| H02 | 167 | Relative stock performance embedded in realistic paired-position discussion; explicit window crosses leap day. |
| H03 | 165 | Negated event with a real scheduled pause nearby; company confirmation is scoped to a single plant and date. |
| H04 | 163 | Confirmed announcement versus future execution; subsidiary versus parent; first availability is after publication. |
| H05 | 176 | Past UP movement beside forward DOWN forecast; 14-day leap-year arithmetic; three distinct dates. |
| H06 | 176 | Two source-status scopes in one article; shared supply-chain context must not transfer entities or confirmation. |
| H07 | 74 | Negation scope and withdrawal of a forecast across a month boundary. |
| H08 | 81 | Conditional two-stock claim; explicit forecast interval differs from publication, availability and trigger deadline. |
| H09 | 81 | Profit forecast surrounded by stock-price language and historical price movement. |
| H10 | 78 | Organisation catalogue domain differs from the directly reported product domain. |
| H11 | 79 | Known stock direction without any supported period; tempting collection-date fallback. |
| H12 | 74 | Leap-day explicit start, future interval distinct from publication and first availability, unsupported domain inference. |

## Calendar checks

- H01: 2027-12-24 + 14 days = 2028-01-07.
- H05: 2028-02-20 + 14 days = 2028-03-05, including 29 February.
- H08: explicit 2027-12-29 to 2028-01-12; the 28 December contract deadline is a separate condition.
- H12: explicit leap-day start, 2028-02-29 to 2028-03-14.
- All references copy first_supported_available_on, never collection date. Relative windows anchor to published_on.

## Semantic assertions and ambiguity controls

- **H01** — One articulated conditional stock thesis. The customer deadline is a condition, not the forecast start or end. Gold dates follow publication plus 14 calendar days; an exact contiguous quotation containing the conditional forecast is expected.
- **H02** — No direction follows from the long/short leg labels. The hypothetical broad retreat and rebound are scenarios, not predictions. The main relative claim is one Idea involving both organisations.
- **H03** — Per the packet contract, denial of occurrence uses NONE. Scheduled calibration is explanatory context for the denied incident, not a second independently developed Idea.
- **H04** — Confirmation is only the signed notice and the conditional plan it announces. The product features and migration procedure explain that plan rather than form separate Ideas.
- **H05** — The observed rally supports the forward valuation thesis, not a second stock judgment. February 2028 has 29 days; the exclusive end is 5 March, based on publication.
- **H06** — The paragraphs deliberately develop independent claims. Gold uses MATERIALS for the solvent delivery and AI_CHIPS for the chip-design change. The negative final sentence blocks an unsupported link without creating a third topic.
- **H07** — The text does not make a positive absolute stock-price forecast. Closing a position is not a prediction that the opposite direction will occur.
- **H08** — The shared contract allocation is one articulated thesis with two judgments. Helix is a customer used to define the condition, not an organisation requiring a new extracted subject ID.
- **H09** — Gold POTENTIAL follows the forward operating-profit expectation as the main claim; NONE is reserved by the packet for stock-outlook Ideas or denials of occurred events. The operating-profit forecast is the only developed prospective claim.
- **H10** — Confirmation is the completed software release. The customer workflow explains the product, without adding unsupported cloud hosting or financial claims.
- **H11** — No numeric default is configured. No period can be inferred from month-end publication, collection timing, or a change in investor valuation.
- **H12** — The trading-range caveat describes position sizing and strength of the argument; it does not make the forecast contingent on an event already claimed to have happened. O1 is supported through the supplied NOVA stock identity.
- **HE01** — The intersection is a misleading subsidiary candidate; NOVA identifies O1 in the union.
- **HE02** — Empty name retrieval does not negate the supported O3 identity in the vector candidate union.
- **HE03** — Empty intersection still permits O5 reuse from the union; the customer is not the seller.
- **HE04** — No candidate matches the explicitly separate legal software company; create the allowed NEW:RidgeCompute identity.
- **HM01** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM02** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM03** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM04** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM05** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM06** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM07** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM08** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM09** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM10** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM11** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **HM12** — Decision follows only the supplied expressions and actual-window fields; no hidden context is required.
- **DESIGN_HORIZON_1** — Expressions such as soon, over the next cycle, after the election, or by year end without a resolvable year are not converted into arbitrary scored calendar windows in this shard. H11 tests a supported direction with no period using MISSING/null; all precise gold windows elsewhere use fixed dates or next two weeks.
- **DESIGN_SCOPE_1** — This is an assistant-authored challenge reference frozen before candidate execution, not owner-validated objective truth. Summaries and supporting rationales admit paraphrase; semantic_checks specify required material qualifications without requiring reason nodes or exact summary wording. Supporting context does not automatically create an independent Idea.

No reference assertion depends on external facts. Confirmation scopes are supplied in the input and limited to signed notices, manifests, receipts or release records described in the associated report. No reason-node output is expected. No exact summary string is scored. An exact contiguous evidence quotation must still be checked against the supplied paragraph, and the reference evidence_any_of only identifies acceptable supporting paragraph locations.

## Mechanical validation and focused review

Python datetime and set checks passed for ISO dates, publication/availability/collection chronology, publication-anchored fourteen-day windows, leap-year windows, all identity unions/intersections, unique IDs, evidence paragraph references, article word counts, and comparison-label totals. No candidate model was run.

The author identified no alternative primary-claim label under the supplied contract. Independent review should focus on H03 (the main claim denies an unplanned shutdown, so NONE) and H09 (the main claim forecasts future operating profit, so POTENTIAL). Supporting historical price movement and scheduled calibration are not separate developed theses. The reference does not constrain exact summary wording, nonessential explanatory details, or reason nodes.
