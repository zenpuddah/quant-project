# Independent pre-run reference audit: shards 1–2

Reviewed all **24 reports, 24 comparisons and 8 identity tasks** against the fixed `prompt_A.txt`. Also read only the baseline packet's convention/catalogue fields to resolve the prompt's references to those fields. No candidate extraction was executed or inspected. References are assistant-authored proposed gold, not human-validated truth.

Snapshot: `hard_shard_1.json` SHA-256 `26da690907350db1bd8b9abc911e0691c9cb93248983218a5cc26948605e9d46`; `hard_shard_2.json` SHA-256 `1f2d826727ec9d70af29b41976c752a03f6b2d9aa088ec808f8da5eea4fcdcbb`.

## Material pre-run grading issues

| Case | Finding | Recommended disposition |
|---|---|---|
| H09 | `POTENTIAL` is plausible for the forward operating-profit expectation. However, the fixed prompt does not exhaustively define `NONE` versus `POTENTIAL` for broad operating forecasts. The review note incorrectly says `NONE` is *reserved* for stock outlooks and denials: the prompt mandates it there but does not make those categories exhaustive. A faithful operating-outlook summary with `NONE` is defensible. | Keep preferred `POTENTIAL`, accept `NONE` as an alternative for this field, or exclude this field from exact scoring. No need to weaken the required empty stock judgments. |
| H18, H19 | Commercial D6 production at the company's own pilot plant reasonably supports either the product domain `AI_CHIPS` or activity domain `CHIP_FABRICATION`. The fixed prompt's main subject/product rule does not fully resolve this product-versus-manufacturing overlap. | Keep preferred `AI_CHIPS`, accept `CHIP_FABRICATION` for both. Do not broaden kinds or phases: H18 remains an unconfirmed asserted past occurrence; H19 remains a scoped company denial with `NONE`. |
| H13 | `semantic_checks` requires retaining the price, while `ambiguity_notes` expressly permits omission of nonessential price details. A concise faithful acquisition-plan summary can omit the price without losing the event or material consent condition. | Make price optional in the semantic rubric. Retain agreement announcement, parties/transaction scope and outstanding customer-consent condition as material. |
| H05, H14 | `evidence_any_of` is narrower than the fixed prompt. H05.p2 directly supports the downside thesis: “The recent rally is why I see downside from here.” H14.p2 directly supports completion: “Our completion notice records the transfer taking effect this morning.” Both are valid contiguous source evidence with report context, although gold only allows p1. The prompt does not require the selected quotation to contain every date/detail appearing in a summary or judgment. | Preaccept H05.p2 and H14.p2 when the actual chosen quotation supports the retained Idea. Prefer semantic evidence validation to a paragraph whitelist. Exact contiguous quotation and valid paragraph ID remain mandatory. |
| H08 | A single conditional joint Idea is the best default. Exact one-Idea grading is nevertheless stronger than “A joint two-stock claim **can** be one Idea with two judgments.” Two faithfully decomposed conditional forecasts can preserve every claim, relation and window while fitting the two-Idea cap. | If prompt remains unchanged, accept a two-Idea representation only when both stock forecasts retain the shared Helix-award condition and joint relationship. Alternatively exclude count/segmentation alone from exact scoring here. This is schema flexibility, not permission to omit the condition or change the judgments. |

Pre-run disposition reported by the parent reviewer: H09 and H18/H19 field alternatives, H05.p2/H14.p2 evidence, and optional H13 price have been applied before the freeze. H08 remains a separately noted split-interpretation caveat; no input change is requested for it. The hashes above identify the reviewed pre-amendment snapshot. This audit does not modify either shard.

## All-case coverage

| Reports | Result |
|---|---|
| H01 | Conditional commercial-acceptance UP thesis; both customers and deadline material. Publication-based 14-day window is correct. |
| H02 | One relative-performance thesis; no absolute stock direction. Gold sound. |
| H03 | Scoped denial plus explanatory calibration; `FACT/NONE` sound. No separate calibration Idea required. |
| H04 | Confirmed conditional plan announcement; subsidiary only. Gold sound. |
| H05 | Historical rise does not override forward DOWN. Dates and phase sound; alternate evidence paragraph noted above. |
| H06 | Two independent ideas: confirmed solvent dispatch and unconfirmed potential chip-package revision. Scope, subjects, domains and ordering sound. |
| H07 | Withdrawn downside view is neither DOWN nor UP; `NONE` and empty judgments sound. |
| H08 | Conditional joint UP/DOWN forecast and explicit interval sound; segmentation flexibility noted above. |
| H09 | Profit forecast supplies no stock judgment. Preferred phase is defensible, but accept alternative noted above. |
| H10 | Completed standalone software release supports `SOFTWARE_TOOLS`, despite catalogue domain. Gold sound. |
| H11 | Explicit DOWN without period: `MISSING/null/null`. Gold sound. |
| H12 | Explicit leap-day interval; trading rationale supplies no business domain. Gold sound. |
| H13 | Acquisition announcement is not closing; consent condition material. Price-rubric contradiction noted above. |
| H14 | Actual acquisition completion dominates earlier-announcement context. Gold sound apart from evidence whitelist. |
| H15 | Corrected 9% cost-per-active-tenant reduction; 19% withdrawn. Gold and denominator requirement sound. |
| H16 | Commercial fabrication-line start; installed capacity is not realised output. Customer/supplier background supplies no extra subject. Gold sound. |
| H17 | Two independently developed stock views; conditional explicit NOVA interval and separate relative DRAG interval. Gold sound. |
| H18 | Unconfirmed assertion of completed commercial production: `RUMOURED_NEWS/OCCURRED`. Domain alternative noted above. |
| H19 | Company denial through specified cutoff: `FACT/NONE`. Engineering samples explain denial. Domain alternative noted above. |
| H20 | Actual general availability, subsidiary operated and billed. Gold sound. |
| H21 | Comparative return thesis with a hypothetical sector scenario; no absolute judgments. Gold sound. |
| H22 | Explicit DOWN without supported period; `MISSING/null/null`. Gold sound. |
| H23 | Corrected 480-tonne September solvent shipments; 840 withdrawn. Customer mention supplies no fabrication claim. Gold sound. |
| H24 | Confirmed announcement of a future limited trial; registration interest is not trial access. Gold sound. |

**Comparisons:** All 24 reference decisions are defensible under the packet's complete-equivalence definition. HM01–HM03 and HM13–HM15 are SAME (6); HM04–HM11 and HM16–HM23 are DIFFERENT (16); HM12 and HM24 are INSUFFICIENT (2). Logical compatibility or one-way entailment does not make the condition/relative-versus-absolute distinctions SAME. No subset-only SAME label found. Unknown versus known windows remain INSUFFICIENT, while unequal known windows remain DIFFERENT.

**Identities:** All 8 candidate unions/intersections are mathematically correct. All 6 reuse decisions and 2 `NEW:RidgeCompute` creates are supported by supplied identity context and the union; no identity alternative identified.

**Dates:** Independently checked relative reference arithmetic: H01 `2027-12-24 + 14 days = 2028-01-07`; H05 `2028-02-20 + 14 days = 2028-03-05`; H17 `2026-10-15 + 10 days = 2026-10-25`. Starts equal publication dates, not availability/collection. Explicit windows and all 24 `available_on` reference values agree with packet fields. No numeric correction errors found.

## Unsupported requirements and coverage limits

- Do not require exact summary wording, every supporting rationale, every figure, or every paragraph to be quoted. Material conditions, negation, scope and target distinctions remain required.
- Keep source confirmation scoped to the main retained claim. Optional ancillary details outside the supplied confirmation scope should not acquire the main claim's confirmed status merely because they share a paragraph.
- A report ID preserves source linkage through the input mapping; do not require a new output `source_id`, reason-node structure, confidence score, or conflict-status field absent from the required schema.
- The incompatible-equally-confirmed-source scenario appears only as REVIEW-GAP-02; it is not a scored report. Do not invent a conflict adjudication requirement. H18/H19 can retain separate source records without selecting a factual winner.
- These two shards contain 41 paragraphs, **no title fields**, no truncated or headline-only inputs, and no genuine three-Idea cap case. Accordingly this audit makes no claim that they test title/body conflicts, partial handling, headline insufficiency or cap omission.

Overall: **56/56 top-level tasks reviewed**. No incorrect comparison label, candidate-set operation, identity choice, date calculation or corrected number found. Material exact-grading flexibility concerns affect 3 report fields (H09/H18/H19), 2 evidence whitelists (H05/H14), 1 contradictory price rule (H13), and 1 segmentation requirement (H08). The intended hard semantic distinctions remain intact.
