"""Offline scoring of the frozen expanded packet; never invokes a model."""
import hashlib,json,copy
from pathlib import Path
import scoring_core as core
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def write(name,value):(ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def run():
 frozen=read(ROOT/'freeze_manifest.json')
 for name,h in frozen['files'].items():
  assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h, 'Frozen file changed: '+name
 results={};combined={}
 for v in 'ABC':
  merged={'reports':[],'identities':[],'comparisons':[]};batches=[]
  for n in range(1,4):
   f=ROOT/f'batch{n}'/f'output_{v}.json'
   info={'batch':n,'file':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None}
   try:
    data=read(f)
    info['shape_errors']=core.shape_errors(data,core.schema)
    for key in merged:
     values=data.get(key,[])
     if isinstance(values,list):merged[key].extend(values)
   except Exception as e:info['parse_error']=str(e)
   batches.append(info)
  result=core.evaluate(merged)
  result['batch_integrity']=batches
  result['all_batches_parse_and_shape_valid']=all(not x.get('shape_errors') and not x.get('parse_error') for x in batches)
  result['fully_matching_identity_tasks']={'passed':sum(not any(e['path'].startswith(i['id']+'.') for e in result['errors']) for i in core.reference['identities']),'total':len(core.reference['identities'])}
  # Report-level exact matching is strict; summary meaning is reviewed separately.
  results[v]=result;combined[v]=merged
  write(f'combined_output_{v}.json',merged)
 write('scores.json',results)
 write('output_schema.json',core.schema)
 tests=[]
 if combined['A']['reports']:
  x=copy.deepcopy(combined['A']);x['reports'].append(copy.deepcopy(x['reports'][0]))
  tests.append({'test':'duplicate_report','pass':any(e['category']=='inventory' for e in core.evaluate(x)['errors'])})
  x=copy.deepcopy(combined['A']);idea=next(i for r in x['reports'] for i in r['ideas'] if i['evidence']);idea['evidence'][0]['quote']='invented excerpt absent from every source'
  tests.append({'test':'fabricated_quote','pass':any(e['category']=='quote_integrity' for e in core.evaluate(x)['errors'])})
  x=copy.deepcopy(combined['A']);diff=next(c['id'] for c in core.reference['comparisons'] if c['decision']=='DIFFERENT');next(c for c in x['comparisons'] if c['id']==diff)['decision']='SAME'
  tests.append({'test':'false_merge','pass':diff in core.evaluate(x)['comparison_same']['false_merges']})
  malformed={'reports':[],'identities':[],'comparisons':[],'unexpected':True}
  tests.append({'test':'unexpected_output_field','pass':bool(core.shape_errors(malformed,core.schema))})
 assert all(x['pass'] for x in tests)
 write('scorer_selfcheck.json',{'status':'Deliberate corrupted copies; not extra model runs.','tests':tests})
 print(json.dumps({v:{k:r[k] for k in ['all_batches_parse_and_shape_valid','report_records_matching_reference','fully_matching_identity_tasks','categories','comparison_same','errors']} for v,r in results.items()},ensure_ascii=False,indent=2))
if __name__=='__main__':run()
