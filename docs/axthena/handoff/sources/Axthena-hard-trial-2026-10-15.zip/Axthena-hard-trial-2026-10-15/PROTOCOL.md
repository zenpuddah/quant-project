# Expanded Axthena diagnostic protocol

Authorised by Badr on 15 October 2026: extend the ChatGPT-only experiment to harder samples that simulate real application inputs. No production implementation or external model API is authorised by this experiment.

Three independent assistant authors prepare 12 reports, four organisation decisions and 12 meaning comparisons each. The resulting 36 reports, 12 identity tasks and 36 comparisons remain fictional. Longer prose, realistic background information, separate clocks, less direct wording and multilingual text replace the earlier sample's explanatory hints.

The previous A/B/C instruction files remain byte-for-byte unchanged for the first comparison. Only the input changes. Temporary output/date conventions remain experimental. Case authors have the contract but do not see candidate outputs. A separate pre-run review checks ambiguous labels; the final inputs and reference are hashed before candidate workers receive them. These are assistant-written references, not human-validated gold.

Each variant sees identical input in three matched batches. Use a fresh worker context for each variant/batch and withhold references, sibling prompts/outputs and previous scores. File isolation is instruction-based, not an enforced security sandbox. No model/reasoning override, external LLM API or interface automation is used. Exact runtime model, seed, sampling, token billing and generation latency remain unknown. One submitted response per variant/batch is retained without repair; no majority voting or successful-retry selection.

Report exact reference agreement separately from semantic support. Mechanical checks cover schema shape, inventory, metadata, selected Idea count, organisation/domain/type/event phase, complete price judgments, identity set arithmetic, comparison labels and source-quotation integrity. A correct quote's existence alone does not establish that it supports the output. Review material qualifications, conditions, attribution, scope and dates independently.

Strict exact matching can penalise a faithful alternative to an imperfect reference. Retain raw scores and document any disputed cases separately. Never silently change a frozen reference to improve a variant's result. Any post-run adjudication must identify the old label, proposed alternative, reason and effect for all variants; it is not a fresh held-out result.

Interpret unsupported-schema cases separately: conflicts requiring on-hold review, vague but meaningful horizons, quoted-voice attribution deferred from V1, cross-domain mappings, failed candidate retrieval, unknown original-version availability. Do not invent product decisions or count known representation gaps as model inference errors.

No stable winner is promised. Larger synthetic tests remain subject to construction bias, correlated cases, single-run variability and reviewer limitations. Real source acquisition, entity-retrieval recall, persistent graph execution, compression, latency, forecast performance and historical operational readiness are not benchmarked here.
