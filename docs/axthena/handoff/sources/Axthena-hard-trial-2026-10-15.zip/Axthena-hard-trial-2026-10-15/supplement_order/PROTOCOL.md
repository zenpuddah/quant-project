# Supplementary order/side check

This is a post-score diagnostic triggered by the repeated answer-position pattern in the original batches. It is not a new held-out dataset or an unbiased selection of the best prompt. Original A/B/C outputs and scores remain unchanged.

Use the existing A prompt, unchanged. It receives the same 36 comparison meanings in one batch, shuffled with Python Random(20261015), renamed SQ01–SQ36, with left/right reversed on every even numbered pair. There are no reports or identity tasks. SAME, DIFFERENT and INSUFFICIENT reference labels are symmetric for these pairs; labels are copied from the original frozen reference.

Freeze files before one fresh extraction context. Withhold mapping, references, prior outputs and scores by instruction. Retain the one submitted output without repair. Check the output shape, empty report/identity arrays, exactly one record per supplied ID, label agreement and semantic support of explanations. A third assistant independently reviews all explanations against the shuffled inputs.

Interpret results only as an order/side robustness observation on these already used meanings under changed batch packaging. It does not isolate causal effects of each change, test repeatability, remove shared-model/reference bias, validate candidate retrieval or establish real-world accuracy. Unknown runtime/model fields stay unknown.
