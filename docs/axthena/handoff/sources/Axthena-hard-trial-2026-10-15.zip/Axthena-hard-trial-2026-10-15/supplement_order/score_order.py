"""Offline check of a separately frozen post-score order/side diagnostic."""
from pathlib import Path
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import scoring_core

def read(name):
    return json.loads((HERE/name).read_text())

def main():
    for name, expected in read('freeze_manifest.json')['files'].items():
        assert hashlib.sha256((HERE/name).read_bytes()).hexdigest() == expected, name
    output = read('output_A.json')
    expected = {x['id']:x['decision'] for x in read('reference.json')['comparisons']}
    rows = output.get('comparisons', [])
    ids = [x.get('id') for x in rows]
    inventory = len(ids) == len(expected) and len(set(ids)) == len(ids) and set(ids) == set(expected)
    checks = [{'id':x.get('id'),'actual':x.get('decision'),'expected':expected.get(x.get('id')),
               'pass':x.get('id') in expected and x.get('decision') == expected[x.get('id')]} for x in rows]
    result = {
        'status':'Post-score diagnostic using already evaluated meanings; not new held-out examples.',
        'worker':'/root/hard_order_run',
        'attempts':1, 'repaired_or_replaced':False,
        'raw_output_sha256':hashlib.sha256((HERE/'output_A.json').read_bytes()).hexdigest(),
        'schema_shape_errors':scoring_core.shape_errors(output, scoring_core.schema),
        'inventory_valid':inventory,
        'empty_reports_and_identities':output.get('reports') == [] and output.get('identities') == [],
        'comparison_labels':{'passed':sum(x['pass'] for x in checks),'total':len(expected)},
        'checks':checks,
        'semantic_support':'See independent semantic_review.md; not scored by this script.',
        'limitations':'A only; one response; same meanings, different packaging/order and 18 side reversals. No isolated causal effect, repetition estimate, retrieval test, model identity or real-world accuracy claim.',
    }
    (HERE/'scores.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
