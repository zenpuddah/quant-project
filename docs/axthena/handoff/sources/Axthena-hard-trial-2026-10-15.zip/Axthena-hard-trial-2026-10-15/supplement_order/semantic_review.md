# Supplement order: independent semantic review

Reviewed only `input.json`, `output_A.json`, and the trial's `prompt_A.txt`. No reference labels, mappings, scores, other outputs, or extraction runs were used. The audit checks each decision and its brief basis against the supplied pair and the packet's comparison definition.

## Counts and conclusion

- Cases reviewed: **36/36**; all IDs occur once and follow input order.
- Output labels: **9 SAME, 24 DIFFERENT, 3 INSUFFICIENT**.
- Clear decision defects: **0**. Clear material basis defects: **0**.
- Straightforward supported cases: **34**. Defensible cases with interpretive notes: **2** (SQ14, SQ35).
- No label correction is established by this review. Borderline notes below identify nuances, not scored errors.

## Per-case audit

| ID | Output | Assessment | Pair and basis check |
|---|---|---|---|
| SQ01 | SAME | Supported | Same joint NOVA-up/DRAG-down forecast, transfer-to-NovaChips condition, and dates. Reversed clause and entity order do not change meaning. |
| SQ02 | SAME | Supported | Chinese and French both report a 12% hosting-cost decline for NovaCloud in completed Q3 versus Q2, at unchanged scope. Full-width numerals do not alter the percentage. |
| SQ03 | DIFFERENT | Supported | French `ne ... plus` means no longer producing; `ne ... pas encore` means not yet producing. Different production histories, correctly distinguished. |
| SQ04 | DIFFERENT | Supported | Share-price growth and operating-profit growth are different targets despite a common product-mix explanation. |
| SQ05 | DIFFERENT | Supported | Subsidiary hosting costs versus parent chip-manufacturing costs differ in entity and activity. |
| SQ06 | INSUFFICIENT | Supported | Text is identical, but only the left has the actual 2028-08-31–2028-09-14 window. Missing dates cannot establish either equal or different windows. |
| SQ07 | INSUFFICIENT | Supported | Identical outlook text; only the right has the 2026-10-13–2026-10-27 window. Basis correctly identifies the side with dates. |
| SQ08 | DIFFERENT | Supported | Expecting DRAG to fall differs from withdrawing that expectation. The basis does not invent an opposite UP forecast. |
| SQ09 | DIFFERENT | Supported | Signing by the deadline is a condition on the left; the right explicitly covers signing and non-signing. |
| SQ10 | SAME | Supported | Chinese/French equivalence preserves the N7-deliveries-resume condition, expected stock rise, and identical window. |
| SQ11 | DIFFERENT | Supported | Relative outperformance does not imply NOVA rises and DRAG falls in absolute terms. |
| SQ12 | DIFFERENT | Supported | Completed retirement after checks differs from an announced retirement plan conditional on checks. |
| SQ13 | DIFFERENT | Supported | French refusal to make any price forecast differs from a forecast of no price movement. |
| SQ14 | SAME | Borderline, defensible | Same stocks, directions, Helix award condition, deadline, and dates. Right's `would make` is more expressly causal than left's `would ... if`; ordinarily a faithful paraphrase here. See note below. |
| SQ15 | DIFFERENT | Supported | Observed past decline versus future forecast is a material temporal/modality distinction, even with identical interval metadata. |
| SQ16 | DIFFERENT | Supported | Actual windows shift by one day. Equal ten-day durations and identical wording do not establish equivalence. |
| SQ17 | DIFFERENT | Supported | French announcement today of a planned December start differs from production beginning today pursuant to a plan. Basis captures the decisive event-stage difference. |
| SQ18 | DIFFERENT | Supported | Completed acquisition versus announced acquisition agreement; announcement does not establish closing. |
| SQ19 | DIFFERENT | Supported | Identical relative wording resolves to different actual windows, 2028-02-20–03-05 versus 02-21–03-06. |
| SQ20 | DIFFERENT | Supported | Otherwise matching cost-per-active-tenant assertions give different reductions, 19% and 9%. |
| SQ21 | DIFFERENT | Supported | Relative NOVA-versus-DRAG outperformance differs from absolute NOVA appreciation; shared rationale and dates do not remove this. |
| SQ22 | DIFFERENT | Supported | Confirmed commencement differs from an unconfirmed possibility. Both modality and event stage change. |
| SQ23 | DIFFERENT | Supported | French left concerns NovaCloud's own hosting costs; ownership context does not transfer that assertion to NovaChips' manufacturing costs. |
| SQ24 | INSUFFICIENT | Supported | Chinese/French outlooks agree on N5 usability and expected stock rise, but the French side lacks the left's actual window. |
| SQ25 | DIFFERENT | Supported | Engineering-sample processing and commencement of commercial production describe different production stages. Shared site/date do not suffice. |
| SQ26 | DIFFERENT | Supported | At least one customer's acceptance versus both customers' acceptance changes the material condition. |
| SQ27 | DIFFERENT | Supported | Certification-conditioned rise differs from expecting a rise even without certification. |
| SQ28 | DIFFERENT | Supported | French `étant signé` presents the agreement as signed; `si ... est signé` leaves signing conditional. |
| SQ29 | SAME | Supported | Both attribute to ForgeFoundry the same denial of the same shutdown at the same plant/date. |
| SQ30 | DIFFERENT | Supported | Chinese `营收` is revenue; French `bénéfice d'exploitation` is operating profit. Same 18% and quarter do not equate the metrics. |
| SQ31 | SAME | Supported | Both languages describe an announced N8 production-start plan for 12 December 2026, with the start still pending. |
| SQ32 | SAME | Supported | `Each of the two` and `both` impose the same certificate-signing condition; `no later than` and `by` preserve the deadline. Windows match. |
| SQ33 | DIFFERENT | Supported | French gives NOVA up and DRAG down; Chinese gives both up. Basis correctly isolates the DRAG direction mismatch. |
| SQ34 | DIFFERENT | Supported | Identical Chinese two-week forecasts have different actual windows spanning year-end. |
| SQ35 | SAME | Borderline, defensible | Same announced Kestrel purchase, NovaChips buyer, consent requirement, and expected closing date. Minor attribution/ownership explicitness differs; see note below. |
| SQ36 | SAME | Supported | Both retain the correction event: withdrawal of 19% and replacement with 9%, for the same quarter and per-tenant hosting-cost metric. |

## Borderline interpretation notes

1. **SQ14 — causal emphasis.** The right says the award would *make* the prices move, whereas the left gives a conditional price prediction. A highly literal treatment could distinguish explicit causation from conditional association. In ordinary financial-outlook language these sentences convey the same conditional joint forecast; the provided SAME decision and basis are defensible. No unsupported correction is recommended.
2. **SQ35 — announcement attribution and ownership.** The left explicitly names NovaChips and DragonLogic as announcing parties but does not literally say `DragonLogic's` Kestrel business. The right explicitly identifies that ownership but uses an unattributed `announced agreement`. SAME is reasonable if these are ordinary restatements of the same transaction. Under strict proposition-by-proposition equivalence, the ownership and announcement-attribution details would need to be resolved before claiming complete equivalence. This is a qualification on the decision, not an established contradiction or definite defect.

Overall, the bases accurately preserve negation, numerical changes, conditional scope, multilingual distinctions, event stages, entity scope, and actual forecast windows. The three missing-window cases appropriately remain INSUFFICIENT rather than assuming equality or asserting a known date difference.
