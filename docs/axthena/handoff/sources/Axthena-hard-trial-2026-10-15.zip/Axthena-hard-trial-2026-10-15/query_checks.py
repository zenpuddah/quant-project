"""Illustrative retrospective source-information reads, not a graph backend."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def read(name):return json.loads((ROOT/name).read_text())
def check_outputs(out):
 byid={r['id']:r for r in out['reports']}
 def eligible(ids,cutoff):return [byid[i] for i in ids if i in byid and byid[i]['available_on']<=cutoff]
 checks=[]
 def check(name,actual,expected):checks.append({'query':name,'actual':actual,'expected':expected,'pass':actual==expected})
 check('H01 unavailable before supported source date, despite earlier header', [r['id'] for r in eligible(['H01'],'2027-12-25')], [])
 check('H01 visible from supported source date, despite later collection', [r['id'] for r in eligible(['H01'],'2027-12-26')], ['H01'])
 check('Acquisition view on 2 October contains announcement only',[(r['id'],i['event_phase']) for r in eligible(['H13','H14'],'2026-10-02') for i in r['ideas']],[('H13','ANNOUNCEMENT')])
 check('D6 source view on 14 October retains then-available rumor',[(r['id'],i['kind'],i['event_phase']) for r in eligible(['H18','H19'],'2026-10-14') for i in r['ideas']],[('H18','RUMOURED_NEWS','OCCURRED')])
 check('D6 source view on 15 October also exposes dated company denial',[(r['id'],i['kind'],i['event_phase']) for r in eligible(['H18','H19'],'2026-10-15') for i in r['ideas']],[('H18','RUMOURED_NEWS','OCCURRED'),('H19','FACT','NONE')])
 check('Subsidiary hosting-cost report has direct subsidiary subject only',[i['org_ids'] for i in byid['H15']['ideas']],[['O3']])
 check('Flat-price forecast produces no UP/DOWN record',[j for i in byid['H31']['ideas'] for j in i['judgments']],[])
 check('Incomplete download keeps supported result',{'status':byid['H30']['processing_status'],'ideas':len(byid['H30']['ideas'])},{'status':'PARTIAL','ideas':1})
 check('Headline-only source keeps no invented content',{'status':byid['H36']['processing_status'],'ideas':len(byid['H36']['ideas'])},{'status':'INSUFFICIENT','ideas':0})
 check('Two-idea cap differs from failed processing',{'status':byid['H28']['processing_status'],'omitted':byid['H28']['cap_omitted'],'ideas':len(byid['H28']['ideas'])},{'status':'COMPLETE','omitted':True,'ideas':2})
 return checks
def main():
 result={'status':'Assistant-authored read checks over saved JSON. Retrospective source dates, not historical operational readiness or truth adjudication. No collection, graph traversal, merge or provider call.','variants':{}}
 for v in 'ABC':
  checks=check_outputs(read(f'combined_output_{v}.json'))
  result['variants'][v]={'passed':sum(c['pass'] for c in checks),'total':len(checks),'checks':checks}
 (ROOT/'query_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({v:{k:d[k] for k in ['passed','total']} for v,d in result['variants'].items()}))
if __name__=='__main__':main()
