# Shard 3 independent pre-run reference audit

Reviewed all 12 reports, 12 comparisons and four identity tasks against the unchanged baseline `prompt_A.txt`. Also inspected the baseline packet's organisation catalogue/date/comparison conventions and output schema. No candidate extraction was run and no input, reference, prompt or scorer was edited.

Audited shard SHA-256: `9c9f08537749c5abb7d7d1b849e1bd7d4786e01c6b82c2ddf0862e05fbc8bc5b`.

Final assessment: all 28 scored tasks have defensible references. The author resolved the two narrow source-domain ambiguities during this audit: H25 now says `sa puce d’IA N7`, and H28 p2 now says `D8人工智能芯片`. I independently verified those edits in shard SHA-256 `a4e8ad2a0813acc3ef8976e6ac767793215c9fc4231e7512deb83363caded4d5`. They preserve the forecast, cap and window difficulties. One proposed semantic evidence check is still stricter than the fixed prompt and must remain a separate diagnostic. No report needs an impossible schema representation; the vague-horizon example is correctly excluded from scoring.

## Findings raised before freezing

1. **H25 domain support — resolved by author:** the original source called N7 `sa puce N7` and subsequently `une puce utilisable`, without identifying it as an AI chip. Gold requires `AI_CHIPS`. The organisation catalogue lists that domain, but rule 2 requires support from the extracted subject in the text and prohibits ungrounded catalogue copying. The author's explicit AI descriptor resolves this ambiguity without changing the conditional forecast, anaphora, misleading title or date difficulty.
2. **H28 second Idea domain support — resolved by author:** original p2 identified `D8芯片`, whereas only the independent NOVA/N9 Idea in p1 explicitly said `人工智能芯片`. Gold requires `AI_CHIPS` for DRAG as well. The author's explicit AI descriptor for D8 resolves the same narrow issue without simplifying the two-Idea cap or missing-window test. This was a domain-support issue, not an objection to the supported DOWN forecast.
3. **H25 evidence diagnostic versus fixed contract:** `review_cases` says evidence must jointly establish the p2 subject and p3 conditional forecast, and that a p3-only quote is insufficient. The fixed prompt requires at least one exact contiguous quotation per Idea, not quotations independently covering every output field. A correct p3 quote, faithful conditional summary and NovaChips linkage resolved from p2 can satisfy that contract. Record full citation coverage separately; do not classify omission of an additional p2 quote as a strict extraction failure. Conversely, a p2-only quote may pass the mechanical `evidence_any_of` check but does not itself substantiate the forecast, which illustrates why quotation integrity and semantic support must remain separate.

## Report-by-report assessment

| Report | Assessment |
|---|---|
| H25 | One OPINION, conditional NOVA DOWN, NONE, RELATIVE 2026-11-03–2026-11-17, available 2026-11-04. Preserve blocked-first-deliveries condition. P1 is a questioned/stale title, not a second bullish Idea. Domain and evidence caveats above. |
| H26 | One FACT/OCCURRED hosting-cost reduction for O3, CLOUD_SOFTWARE; duplicate p2/p3 is one Idea. Full-width １２％ means 12%. Ownership context does not attach O1. Confirmation scope covers the completed cost actions. |
| H27 | One CONFIRMED_NEWS/ANNOUNCEMENT for O1, AI_CHIPS. Main event is the confirmed announcement of a planned 12 December start; production has not started. P1 is explicitly corrected, not another independent claim to retain. |
| H28 | Two independent OPINION/NONE Ideas in paragraph order. NOVA UP has explicit 9–23 November dates; DRAG DOWN has no supported horizon and correctly uses MISSING/null. P1 dates modify its NOVA claim; p2 contains no same-period cue. `本周手记` dates the notes, not the DRAG forecast. Incidental O4 sign detail is omitted under the cap, so COMPLETE with cap_omitted=true. D8 domain caveat above. |
| H29 | One CONFIRMED_NEWS/OCCURRED signed agreement involving NEW:RidgeCompute and O1, SOFTWARE_TOOLS. No O5 linkage and no price judgment. Registration context identifies the new company; the imperative footer is page contamination. Commercial release remains future and undated, but the main claim is signing. |
| H30 | One retained OPINION/NONE DRAG UP Idea, PARTIAL, no cap omission. RELATIVE 2026-12-26–2027-01-09 is exactly 14 calendar days anchored to publication, not 27 December availability. The dangling NovaCloud conditional does not provide a second complete Idea. |
| H31 | One OPINION/NONE about expected flat NOVA price. Empty judgments is correct because only UP/DOWN is allowed; the summary must retain the actual flat-price forecast and its stated period. No schema impossibility. |
| H32 | One FACT/OCCURRED about completed-quarter operating profit, AI_CHIPS/O2. An 18% profit increase supplies no price judgment. |
| H33 | One RUMOURED_NEWS/NONE denying a production stoppage. The correction is an outlet assertion with empty confirmation scope. Its production negation must survive; self-correction does not make it qualifying confirmation. |
| H34 | One OPINION/NONE, NOVA UP with MISSING/null dates. A definite direction is present; no duration is present. AI-chip subject is explicit despite software tools in the rationale. |
| H35 | One RUMOURED_NEWS/POTENTIAL AI-chip partnership for O1/O4. No signed agreement is asserted; the old shared-booth photograph is not execution evidence. Domain remains AI_CHIPS, not the partner's fabrication catalogue domain. |
| H36 | INSUFFICIENT with no Ideas: metadata and p2 explicitly establish title-only acquisition. The question in the title does not supply body evidence. |

All report availability dates match first_supported_available_on. The gold expects 12 retained Ideas and five price judgments across 10 COMPLETE, one PARTIAL and one INSUFFICIENT report. No exact Idea-count or event-phase ambiguity requiring a gold revision was found. No past stock movement is mislabelled as a forecast; H26/H32 are completed business metrics and H31 is a future flat-price forecast.

## Comparisons

| Task | Gold | Audit |
|---|---|---|
| HM25 | SAME | French and Chinese preserve the same resumed-N7-delivery condition, NOVA UP target and known window. Neither contains the blocked-delivery condition of H25, and the task must be judged on its own supplied texts. |
| HM26 | SAME | Same completed Q3 hosting-cost decline, Q2 comparator, constant scope and 12% magnitude; full-width digits do not alter meaning. |
| HM27 | SAME | Same announced N8 production plan, same 12 December 2026 intended start, production not yet started. |
| HM28 | DIFFERENT | No price forecast versus a forecast of no price movement. |
| HM29 | DIFFERENT | Identical words but actual windows differ by a day. |
| HM30 | DIFFERENT | `ne produit plus` means no longer producing; `ne produit pas encore` means not yet producing. Different development stage. |
| HM31 | DIFFERENT | DRAG DOWN versus DRAG UP; the shared order-transfer catalyst and NOVA UP do not erase that conflict. |
| HM32 | DIFFERENT | Conditional signing versus asserted completed signing. |
| HM33 | DIFFERENT | Operating profit versus revenue, despite matching organisation, quarter and percentage. |
| HM34 | DIFFERENT | Plan announcement versus actual production start. |
| HM35 | DIFFERENT | Subsidiary cloud-hosting costs versus parent's chip-manufacturing costs. |
| HM36 | INSUFFICIENT | Same direction/catalyst but unknown versus known actual window; equality cannot be assumed. |

All 12 labels are justified: three SAME, eight DIFFERENT and one INSUFFICIENT. No unjustified equivalence was found.

## Identity tasks and schema limits

All four unions and intersections were independently recomputed and match the reference. HE09 reuses O1, HE10 reuses O3, HE11 creates NEW:RidgeCompute, and HE12 reuses O4. Full-width letters, bilingual naming, a nonbreaking space and a nonbreaking hyphen are each resolved through explicit contextual identity evidence, not similarity alone. The wrong intersection candidate in HE11/HE12 does not override the union inspection rule.

The excluded HR3-GAP-01 `À moyen terme` example is a genuine unresolved horizon representation issue and should remain unscored. None of the 28 scored tasks requires FLAT, attribution, a detailed condition field or another unsupported schema value: material qualifications can remain in summaries. The original source difficulty should otherwise be retained.
