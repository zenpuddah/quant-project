# Hard shard 2 author review

Authored from the baseline prompt, packet and reference conventions only. All companies, people, outlets and events are fictional. No extraction model was run. This is an assistant-authored reference awaiting independent review, not objective or owner-validated gold.

The shard contains 12 reports (H13–H24), 4 identity tasks (HE05–HE08), and 12 meaning comparisons (HM13–HM24). Six reports contain 150–250 words and six contain 60–130 words. H17 has two separately developed ideas; the other reports each have one dominant idea. Every report is complete and none needs a cap omission.

| Report | Words | Intended focus |
|---|---:|---|
| H13 | 185 | Long acquisition article; distinguish a confirmed agreement announcement from completion, and exclude ownership/geographical background. |
| H14 | 176 | Completion article includes substantial prior-announcement context and a past condition that is now fulfilled. |
| H15 | 181 | Correction inside a natural subsidiary article; availability differs from publication and collection dates. |
| H16 | 180 | Actual production versus engineering runs, installed capacity versus realised output, and supplier/customer domain leakage. |
| H17 | 175 | Two fully developed stock ideas, distinct causes and windows, with a material condition on only one. |
| H18 | 188 | Detailed asserted past event remains unconfirmed; engineering/commercial distinction later receives a contradictory source report. |
| H19 | 70 | Authoritative denial with real engineering activity in the same paragraph. |
| H20 | 70 | Actual software availability after a trial, with parent ownership and differing availability metadata. |
| H21 | 72 | Natural relative-return thesis with a sector-downside scenario but no absolute direction. |
| H22 | 66 | Explicit bearish stock view with temporal-sounding language that supplies no usable duration. |
| H23 | 70 | Corrected numeric fact with a named customer and tempting fabrication-domain association. |
| H24 | 69 | A confirmed product bulletin announcing future trial availability, with registration already possible. |

Comparison distribution: **3 SAME, 8 DIFFERENT, 1 INSUFFICIENT**. Identity distribution: **3 REUSE, 1 CREATE**. Report reference: **13 retained Ideas**, with 3 stock judgments; H21 has no absolute forecast and H22 has an explicit direction with a missing window.

Gold entries follow the prior reference shape and add optional `semantic_checks` strings to make correction, qualification and scope expectations reviewable. Evidence paragraph IDs identify permissible exact-quotation locations; the extractor must still supply an exact contiguous quotation. Summaries should be judged for material meaning rather than wording or retention of every subordinate detail.

Correction handling is explicit: H15 withdraws 19% and replaces it with 9%; H23 withdraws 840 tonnes and replaces it with 480. Neither is an unresolved contradiction. H15 and H20 intentionally have publication metadata earlier than first supported availability; H22 similarly separates publication from availability and collection.

H18 and H19 are separate source reports about the same cutoff. H18 asserts a past commercial-production start without qualifying confirmation; H19 supplies a scoped company denial. Their source identities, claim modalities and event phases must remain separate. No external truth adjudication is needed.

A genuinely incompatible pair of qualifying company confirmations is documented only in `REVIEW-GAP-02`. The existing schema has no explicit cross-report conflict state or winner-selection policy. It would be unfair to require an unsupported ON_HOLD status or silently choose a source. This design gap is not part of the scored report count.

No narrow articulation alternative is needed for the authored reports: supporting contract terms, operating details and background customer/parent mentions remain within each dominant event. H17 explicitly develops independent outlooks. Independent review may nevertheless flag a reasonable alternative segmentation before freezing the benchmark; any such case should be documented rather than counted as an unqualified model error.

Checks run: JSON serialization and parse; required input/reference key shapes; unique IDs; allowed enum/domain values; matching input/reference order and counts; word bands; paragraph evidence IDs; identity set arithmetic; comparison distribution; relative date arithmetic. No candidate or extraction model execution occurred.
