# Axthena: six unscored contract-review cases

Read-only review, 2026-10-15. These are **synthetic design cases outside scored accuracy**. They were not submitted to an LLM and are not failed trial outputs. No production, graph, prompt, schema, or reference changes were made. All suggested changes below are **proposals for review**, not accepted product decisions.

Basis: `Axthena-chat-trial-2026-10-15/prompt_A.txt`, its `input.json` and `output_schema.json`, and the accepted AX/ENG entries named below in `Axthena-context.md` and `Axthena-engineering-context.md`. The original pilot intentionally supplies completed candidate lists, qualifying confirmation scopes, one supported availability date, and narrow date conventions. Its success does not test these boundaries.

| ID | Primary classification | What is missing from the current contract |
|---|---|---|
| G01 | Representation failure; unresolved read policy | Conflicting qualifying confirmations and dated hold/review state |
| G02 | Deliberate V2 exclusion; missing trial rule/coverage | Quoted stock judgments must remain excluded, with no invented publisher position |
| G03 | Representation failure; unresolved interpretation | Qualitative source horizon and origin of any inferred/default interval |
| G04 | Representation failure | Organisation-to-domain associations within one joint Idea |
| G05 | Representation failure; missing operational coverage | Retrieval failure versus completed no-selection, plus retained identity uncertainty |
| G06 | Representation failure; unresolved availability policy; V2 boundary | Exact captured evidence identity and uncertainty about its earlier availability |

“Representation failure” here means the prescribed structured output cannot express the required distinction. A summary or verbatim quote may preserve words for a person to inspect; that does not make the absent distinction available to structured reads. Missing coverage alone is not evidence that an LLM would answer incorrectly.

## G01 — Two qualifying systems disagree about one occurrence

**Synthetic vignette.** The packet explicitly stipulates that both confirmation processes qualify for the same claim, line and date. On 5 October, ForgeFoundry's signed operating notice says, “The F2 line began production today.” On 6 October, a separately supplied qualifying inspection record says, “The F2 line had not begun production on 5 October.” There is no user review decision. This is disagreement about the same occurrence, not a plan versus execution or different dates.

**Accepted invariant / open decision.** AX-003 preserves confirmation scope, process and time. AX-004 requires on hold and personal review, preserves both conclusions, and forbids automatic resolution. Availability of held information to reads and the exact review outcomes remain open. Qualification is supplied here so this case does not decide which authorities qualify.

**Why inadequate.** Rule 3 and `kind` offer only FACT, CONFIRMED_NEWS, RUMOURED_NEWS or OPINION. `processing_status` describes processing adequacy, not claim conflict. There is no conflict link, hold state, or dated review state. Assigning both records ordinary confirmation states cannot express that their joint use is on hold; calling one rumoured, insufficient or automatically false would change the accepted meaning.

**Minimum proposed fix.** In a separately reviewed experimental extension, add a claim-conflict/hold annotation linking the competing scoped conclusions and their evidence; retain source categories separately. Add a dated user-decision reference only if one exists. Do not select a hold-read inclusion/exclusion policy in this case.

**Review test.** The reviewer should be able to recover both conclusions and the common claim, see an unresolved hold, and identify no automatic winner. A second supplied packet with a later user decision should preserve the pre-decision hold for an earlier cutoff. Test read inclusion separately only after its policy is selected.

## G02 — The prominent outlook belongs to a quoted analyst

**Synthetic vignette.** An outlet article's main paragraph says, “Analyst Mira said, ‘I expect NOVA shares to rise over the next two weeks.’ The newspaper reports her view and expresses no stock-price forecast of its own.” Its later paragraph contains incidental company history, not an alternative developed outlook.

**Accepted invariant / open decision.** AX-026 deliberately excludes other people's quoted judgments from V1 judgment extraction and expressed-agreement scoring. Preserve the original quotation; do not attribute it to the publisher, infer zero agreement, or replace the prominent Idea solely to obtain a judgment. Detailed quote attribution, endorsement treatment and quoted-voice support belong to V2. This is not exclusion of first-party company announcements.

**Why inadequate.** Shared rule 4 says a supported absolute UP/DOWN forecast qualifies but never states the accepted quoted-judgment exclusion. The output could represent the correct empty `judgments` list, so this is principally a rule/coverage gap, not proof that every output is impossible. There is also no structured omission reason to distinguish deliberately excluded quoted direction from no forecast in the source. Evidence and summary can retain the quoted wording without manufacturing a publisher position; exact `kind` treatment of quotation-dominated reporting should not be silently settled here.

**Minimum proposed fix.** Add an explicit trial rule enforcing AX-026 and a paired quoted-versus-source-own boundary case. If structured omission accounting is needed, propose a minimal diagnostic reason such as `QUOTED_JUDGMENT_V2_EXCLUDED`; do not implement quoted-speaker judgment records or support scoring.

**Review test.** The relayed quote yields no UP/DOWN judgment or publisher endorsement, while the same words in Mira's own first-person report remain eligible. The original quote remains recoverable, and its prominent Idea is not replaced to manufacture a score. Keep unresolved category/omission-field design out of scored labels until reviewed.

## G03 — A meaningful horizon is qualitative, not a duration

**Synthetic vignette.** A personal report dated 5 October says, “I expect NOVA shares to rise over the medium term as the N1 launch matures.” Compare with “I expect NOVA shares to rise; I give no time horizon.” Neither packet configures a numerical fallback or a mapping for “medium term.”

**Accepted invariant / open decision.** AX-031 distinguishes source-stated wording, language-inferred periods and configured fallback periods. ENG-034 preserves missing information and the origin of a working period; it does not accept seven days. Exact categories, interpretation criteria and numerical mappings remain open. The direction must survive absent exact dates.

**Why inadequate.** Rule 5 reserves EXPLICIT for fixed dates and RELATIVE for source durations anchored to publication; MISSING covers unsupported periods. A qualitative horizon has useful source meaning but no defined numeric duration. Encoding both examples as MISSING loses their structured distinction; inventing a relative date range assigns an unselected interpretation. The schema cannot label a period as source qualitative, inferred or configured fallback. Existing R16 only tests wholly unstated timing.

**Minimum proposed fix.** Preserve `horizon_text` and separate its source presence/type from whether a numerical window is resolved. If a working range is eventually assigned, require its origin and interpretation/configuration reference. Leave numeric dates null while no mapping is selected; do not pick a duration or assume the two complete opinions are equivalent.

**Review test.** Both examples retain NOVA UP. Only the first records the source's qualitative horizon. Neither fabricates exact dates. A later hypothetical configured mapping produces a separately identifiable interpretation rather than rewriting what the source stated. Any comparison requiring precise window equality remains unresolved unless supporting information is supplied.

## G04 — One joint opinion concerns different domains at each organisation

**Synthetic vignette.** Mira writes, “NovaChips' AI-chip hardware strategy and NovaCloud's cloud-software distribution strategy reinforce each other in a single integrated offering. My view concerns the two strategies together.” The packet supplies O1 and O3 as distinct organisations and supports AI_CHIPS for O1 and CLOUD_SOFTWARE for O3. There is no stock-price forecast.

**Accepted invariant / open decision.** AX-021 accepts one opinion linked to several organisations, with each organisation's relevant domain, and warns against multiplying opinions because of multiple targets. ENG-035 preserves joint Ideas; ENG-032 does not transfer organisation-specific dependencies through a shared activity category. Unspecified-domain and indirect-relevance handling remain open, but both associations are explicit here.

**Why inadequate.** The output has an unpaired `org_ids` list and one scalar `domain`. Choosing AI_CHIPS or CLOUD_SOFTWARE drops the other relevant association; assigning either to both is unsupported. Splitting one relationship into two Ideas solely to fit the schema violates the joint-opinion boundary. A generic main-subject domain can still be useful, but is not a substitute for the accepted organisation/domain mapping.

**Minimum proposed fix.** Propose an explicit association list, for example O1→AI_CHIPS and O3→CLOUD_SOFTWARE, within one Idea. Any retained overall main-subject field should have a separate defined purpose. Do not copy all catalogue domains or infer dependencies.

**Review test.** One Idea and one source expression retain both exact pairs, with no stock judgments, parent-only promotion or extra opinion count. Swap the two domains in a deliberately defective representation: the review must detect the wrong pairings, even though the set of organisations and set of domains remain unchanged.

## G05 — Empty candidates resulted from failed retrieval

**Synthetic vignette.** For a supported RidgeCompute mention, the name lookup times out and the vector lookup returns an error; neither supplies a usable candidate set. Contrast this with two successful searches returning empty lists. A third contrast has successful lists but insufficient identity evidence to select an existing candidate after comparison.

**Accepted invariant / open decision.** ENG-026 requires automatic creation whenever the completed AI identity decision selects no existing organisation, including uncertain comparison, with uncertainty and alternatives retained. It explicitly distinguishes retrieval/extraction/tool failure from a completed decision. ENG-006 keeps operational failure separate from domain records. Precise metadata/retry handling remains open; a manual identity approval gate is not permitted by the accepted rule.

**Why inadequate.** Rule 8 assumes retrieval was supplied and requires REUSE or CREATE for every identity task. The schema has no retrieval status, completed-decision marker, uncertainty or alternative interpretation metadata. Treating failure as two empty candidate lists forces a phantom no-match; treating uncertain completed comparison as fully certain creation loses the accepted uncertainty. Original E1–E5 never exercise these states, and the pilot does not measure retrieval quality.

**Minimum proposed fix.** Add a separate operational envelope for retrieval outcome and whether comparison completed. Require union/intersection only for defined supplied sets, and a domain action only after a completed decision. Preserve uncertain comparison metadata alongside automatic CREATE. This is failure observability, not an approval queue or a reversal of automatic creation.

**Review test.** Failed retrieval cannot masquerade as completed no-match or emit a new organisation on that basis. Successful empty retrieval followed by completed no-selection yields CREATE automatically. Completed uncertain no-selection also yields CREATE automatically, retaining uncertainty and available alternatives. Review retry consistency as a separate operational contract; do not claim that this text fixture benchmarks retrieval.

## G06 — The dated page does not establish the date of its captured wording

**Synthetic vignette.** On Wednesday 7 October, a retained snapshot is collected from a page whose publication header still says Monday 5 October. The captured paragraph says, “Correction: the line has not started production; our earlier wording said it had.” There is no retained Monday body and no reliable time for the correction. The exact Wednesday snapshot and paragraph are available; the earlier wording and its availability are not. This packet is supplied directly, without asking Axthena to discover edits.

**Accepted invariant / open decision.** AX-052 forbids treating a Wednesday correction as Monday evidence merely because the URL is Monday-dated; source-aligned history is not proof of historical Axthena possession. ENG-003 retains exact evidence actually used, source/collection dates and processing provenance, while deliberately deferring active edit discovery and detailed edit-history handling to V2. Earlier-availability uncertainty and historical read policy remain unselected.

**Why inadequate.** Rule 6 assumes a single `first_supported_available_on` is already known. Mandatory `available_on` is a non-null date with no availability basis/state. Evidence names only a report paragraph, with no explicit immutable snapshot binding unless an external manifest supplies one. The current packet's unique report IDs and retained input do support exact quotations for that packet, so this is an extension boundary, not a claim that its existing quotes are untraceable. In this scenario a Monday date would be unsupported, while a Wednesday observation date must not silently become a claim of first publication. Current output cannot express that distinction.

**Minimum proposed fix.** Propose an immutable evidence-snapshot reference, or a documented invariant that report IDs resolve to exactly one immutable retained snapshot, plus availability basis/status separate from observed collection time. Permit unknown earlier availability without fabricating a date. Select historical eligibility policy separately; preserve actual processing provenance through the run manifest. Do not add edit monitoring, reconstruct an unseen original, or claim complete revision history.

**Review test.** The exact quoted wording resolves to the retained Wednesday snapshot. Its correction is not accepted as Monday content. No Monday passage is invented, and the unknown change time remains unknown. A contrast packet with separately supplied evidence of Monday availability can support Monday source history. No ordinary read triggers collection or edit discovery.

## Use in the expanded review

Keep these six cases in a design-review appendix with `scored = false` in any accompanying catalogue. Record whether each proposal is accepted, revised, deferred or rejected. A reviewer may check the accepted invariants now, but do not award accuracy points for field values the current contract cannot carry, force one answer to unresolved policy questions, or score a V2 feature as a required V1 capability. After a contract change is explicitly reviewed, a narrower case may move into a future frozen trial under its own schema and prompt version.
