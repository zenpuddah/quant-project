# Expanded diagnostic: benchmark integrity audit

Read-only audit, 15 October 2026. No candidate reruns or changes to inputs, prompts, references, scripts or outputs. Only this review was added. Reviewed the protocol, scorer, query checks, freeze/amendment records, scores, submitted packets, and relevant raw outputs; also consulted the separate complete semantic reviews.

**Finding:** No artifact mismatch, direct reference contamination, or scoring failure was found that invalidates the reported structured agreement. The clean result is defensible for this controlled packet. It is not full semantic accuracy, independent real-world accuracy, or evidence of a stable A/B/C winner.

## Integrity checks

- All **30 frozen file hashes** match the manifest. A/B/C prompts are byte-identical to the preceding trial's local prompt files. The declared pre-run alternatives and evidence/rubric amendments are present in the frozen references; no post-run reference change is evident.
- Every combined output equals its three raw batch outputs concatenated by group. Read-only calls to `scoring_core.evaluate` reproduce every saved core score field; the saved inputs and references exactly partition into the three batches. All actual outputs separately pass schema and inventory checks.
- All nine `chat_copy` files contain exactly the corresponding prompt plus the batch input. A/B/C receive identical packet bytes within a batch. No reference-only `semantic_checks`, `accepted_values`, `evidence_any_of`, or reference provenance is embedded in those inputs. No instantiated answer-label fields were found in packet data.
- The saved artifacts cannot independently prove worker access history, one-shot execution, or enforced isolation. The protocol correctly describes instruction-based isolation and unknown runtime settings. Matching hashes establish current artifact consistency, not a tamper-proof execution chronology.

## What the denominators mean

| Measure, per variant | Verified result | Meaning |
|---|---:|---|
| Report records matching scored fields | 36/36 | Metadata, Idea count, selected structured fields, judgment arrays, quote checks; excludes summary semantics |
| Retained Ideas | 38 | Includes 25 Ideas with empty judgment arrays |
| Judgment-array agreement | 38/38 | **13 nonempty arrays containing 14 stock judgments**, not 38 forecasts |
| Fully matching identity tasks | 12/12 | Nine REUSE and three CREATE decisions using supplied candidates/context |
| Comparison-label agreement | 36/36 | Nine SAME, 24 DIFFERENT, three INSUFFICIENT; basis semantics are separately reviewed |
| Exact quoted spans | A 42/42; B 48/48; C 52/52 | Output-dependent span counts, not equal independent test sets |
| Retrospective JSON read checks | 10/10 | Hand-authored checks over the same extracted records |

The 36 reports include 34 COMPLETE, one PARTIAL and one INSUFFICIENT report; the last has no Ideas. The three variants reuse the same cases. Do not describe 108 report evaluations as 108 independent reports, or combine differing quote totals into a comparative aggregate accuracy score. “Structured reference agreement, including predeclared alternatives” is more precise than full-record exact matching: H09 permits two phases and H18/H19 permit two domains.

## Scorer boundaries and prose-only meaning

`summary` and comparison `basis` are checked only for nonempty string shape. `semantic_checks` in the reference is not executed. Exact quotation checking proves that text occurs in the cited report paragraph; evidence coverage requires an accepted paragraph, not that the selected words entail every output claim. Consequently the mechanical score alone could remain perfect despite a wrong summary, lost condition, bad rationale, or an irrelevant substring from an accepted paragraph. The protocol explicitly requires separate semantic review, and those reviews cover all 114 retained summaries and 108 comparison bases across A/B/C. They report no material semantic defect, while documenting minor ambiguity and citation-completeness observations. This audit spot-checked the material conditional cases and found their conditions retained.

In particular, H01 (both customers' commercial acceptance), H08 (Helix award), H17's NOVA Idea (scheduled certification), and H25 (blocked deliveries) have conditional stock judgments. All variants preserve the conditions in summaries, but their structured `judgments` contain only stock, direction and dates. A consumer reading UP/DOWN alone cannot recover the conditions. H31 similarly preserves a flat forecast in prose while returning `judgments=[]`. These are representation/read-boundary caveats, not current extraction failures; the query checks do not test condition-aware or flat-forecast retrieval.

The report-pass subtotal also excludes global schema/inventory failures. Those checks pass separately here, so this does not inflate the present result; future summaries must retain the separate checks. The noted H08 segmentation ambiguity could penalize a faithful split output in another run, but all current variants use the accepted joint representation.

## Construction and scope limits

The packet is more linguistically demanding than the pilot but remains strongly scaffolded. Every report provides the correct availability anchor, source type and body status. Sixteen provide curated confirmation scopes, sometimes stating event/scope distinctions explicitly. Identity contexts often directly resolve canonical names or independence; retrieval is supplied and `NEW:RidgeCompute` is named in the prompt. These are disclosed contract inputs, not reference leakage, but they remove substantial real ingestion/identity work.

There is also cross-task assistance: comparison tasks supply condensed claims, resolved organisation IDs and normalized windows for some reports in the same packet. For example, HM01 supplies H01's material condition and calculated window. Each batch additionally uses the same comparison-label order: three SAME, eight DIFFERENT, then one INSUFFICIENT. This predictable layout weakens discrimination. It does not establish shortcut use; the reviewed explanations support the actual decisions.

The ten query checks perform direct JSON selection and comparisons over these same records. They do not exercise collection, retrieval recall, graph traversal, persistence, merging, conflict resolution, or historical system possession. The six contract-gap cases remain expressly unscored. References and semantic judgments are assistant-authored rather than owner-validated, cases share entities and templates, and there is one response per variant/batch with unknown sampling settings. These limitations support reporting a tied clean result on the supplied synthetic diagnostic, with no generalization or production-readiness claim.
