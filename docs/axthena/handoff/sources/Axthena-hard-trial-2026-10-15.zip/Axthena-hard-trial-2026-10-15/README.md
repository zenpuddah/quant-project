# Axthena expanded experimental packet

All articles are fictional. This packet extends the earlier 17-report pilot with 36 new reports, 12 supplied identity tasks and 36 comparison tasks. It is an extraction and final-comparison experiment, not a product implementation or model leaderboard.

## Start here

- `Axthena-hard-trial-results-2026-10-15.md`: findings, limitations and proposed next review.
- `Axthena-hard-samples-2026-10-15.md`: every original source and unchanged A output in one readable file.
- `combined_output_A.json`: A outputs concatenated across batches; B/C have equivalent files.
- `hard_contract_gaps.md`: six unscored design cases and proposed tests; no remedies accepted yet.

## Execution and review

- `PROTOCOL.md`, `freeze_manifest.json`, `run_manifest.json`: method, frozen file hashes, execution provenance and unknown settings.
- `prompt_A.txt`, `prompt_B.txt`, `prompt_C.txt`: instructions unchanged from the first pilot.
- `batch1/` through `batch3/`: identical input for each variant, copyable prompt-plus-input files, local references and every raw output.
- `input.json`, `reference.json`: combined cases and assistant-authored expected answers, not owner-approved truth.
- `pre_run_amendments.json`, `hard_prerun_review_12.md`, `hard_prerun_review_3.md`: pre-run ambiguity review. References were not changed after execution.
- `semantic_review_1.md` through `semantic_review_3.md`: meaning and quotation review for all retained outputs.
- `benchmark_integrity_review.md`: independent inspection of the original 3×3 trial and scoring boundaries.
- `scores.json`: structured results, errors and exact quotation locations in code points and UTF-8 bytes.
- `query_checks.json`: ten illustrative reads per variant over retained JSON; no graph backend.
- `author_shard_*.json`, `author_review_*.md`: construction provenance; never part of candidate input.
- `supplement_order/`: separately frozen, post-score comparison-order/side diagnostic; not additional independent examples. Its separate review flags two borderline SAME interpretations without changing frozen labels.

## Recalculate saved results without any model call

With Python 3, from this directory:

```bash
python3 score_hard.py
python3 query_checks.py
python3 supplement_order/score_order.py
```

Only the Python standard library is used. `score_hard.py` verifies frozen file hashes and regenerates combined outputs, scores, the emitted schema and deliberate-defect checks. Its shape checker covers this experiment's schema subset, not the whole JSON Schema standard. It does not judge free-text meaning; see the separate reviews. Scoring can be reproduced from retained responses; model generation itself is not reproducible from a pinned model/seed.

For a new ChatGPT trial, use a separate copy of the packet and a fresh conversation for each `chat_copy` file. Do not include references, prior outputs or review notes. Record the visible model/settings if known, preserve failures, and do not overwrite the retained experiment. Ordinary ChatGPT-interface results may differ from these in-session assistant-worker runs.

## Scope boundary

No C++ application, live Cypher execution, existing fixture mutation, provider adapter, real-source collection, paid model setup, predictive training or quant integration is included. Human output/query review and production specification/plan review remain required. Numerical fallback periods, conflict-read policy and the proposed missing fields are not selected by this trial.
