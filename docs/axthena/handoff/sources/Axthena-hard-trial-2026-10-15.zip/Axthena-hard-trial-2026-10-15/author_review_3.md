# Hard shard 3 author review

Independent synthetic authoring only. No candidate model was executed. All organisations and events are fictional. The shard inherits the unchanged baseline contract and catalogue.

Contains 12 reports (H25–H36), 4 identity tasks (HE09–HE12), and 12 comparison tasks (HM25–HM36). Comparison balance: 3 SAME, 8 DIFFERENT, 1 INSUFFICIENT.

Six long articles are H25–H30; six short reports are H31–H36. French lengths use whitespace words. Chinese uses CJK and total character counts, since whitespace is not a word measure; a transparent rough length equivalence of two CJK characters per word puts long Chinese articles at about 175–219 words and H33/H35 at about 61–63 words. H36 intentionally has only a headline plus retrieval-status metadata: its natural short length is an explicit exception, not padded article prose.

The reference uses the baseline report/identity/comparison gold format, including evidence_any_of paragraph IDs. Per-case semantic_checks are review guidance because paragraph membership alone cannot prove full support. H25 particularly needs evidence covering the entity in p2 and the conditional direction/duration in p3.

No scored stock outlook relies on a third-party quotation. The sole directly quoted imperative is irrelevant page-footer contamination in H29. A vague-horizon vignette is unscored HR3-GAP-01; no arbitrary dates or unjustified MISSING state are imposed.

| ID | Length class | Words | CJK chars | Total chars |
|---|---|---:|---:|---:|
| H25 | long | 182 | 0 | 1139 |
| H26 | long | 4 | 438 | 521 |
| H27 | long | 184 | 0 | 1123 |
| H28 | long | 3 | 354 | 449 |
| H29 | long | 202 | 0 | 1310 |
| H30 | long | 3 | 369 | 421 |
| H31 | short | 85 | 0 | 517 |
| H32 | short | 82 | 0 | 546 |
| H33 | short | 1 | 122 | 143 |
| H34 | short | 84 | 0 | 517 |
| H35 | short | 1 | 125 | 154 |
| H36 | short | 2 | 68 | 97 |

## Case review

- **H25** — French conditional forecast, misleading title, cross-paragraph anaphora, publication anchoring instead of availability/collection. No third-party quoted voice. Scored under the unchanged V1 contract.
  - Semantic check: Retain the blocked-delivery condition; do not convert the forecast into unconditional DOWN.
  - Semantic check: Evidence must jointly establish the NovaChips/N7 subject from p2 and the DOWN/two-week conditional from p3. One extract from p3 alone is not full semantic grounding.
  - Semantic check: The p1 headline is corrected by the developed body.
- **H26** — Chinese full-width percentage; duplicate paragraph is one Idea; subsidiary ownership does not transfer the claim to O1. No third-party quoted voice. Scored under the unchanged V1 contract. Chinese length uses character counts rather than whitespace word counts; retain natural text. H36 is deliberately headline-only.
  - Semantic check: Retain one hosting-cost Idea, not two copies.
  - Semantic check: Do not attach O1 merely because the parent appears in ownership/cover context.
- **H27** — French headline/body correction; confirmed plan announcement must not become an occurred or guaranteed future production start. No third-party quoted voice. Scored under the unchanged V1 contract.
  - Semantic check: Summary must say announced plan and retain the intended start date as planned.
  - Semantic check: Do not treat p1 as an additional independent occurrence Idea.
- **H28** — Chinese two developed independent forecasts plus incidental third; explicit period must not leak from NOVA to DRAG. No third-party quoted voice. Scored under the unchanged V1 contract. Chinese length uses character counts rather than whitespace word counts; retain natural text. H36 is deliberately headline-only.
  - Semantic check: Retain two separate Ideas in paragraph order, not one joint order-transfer Idea.
  - Semantic check: DRAG has a supported DOWN direction with no supported duration: MISSING and null dates.
  - Semantic check: Ignore the incidental O4 sign detail under the two-Idea cap and set cap_omitted=true.
- **H29** — French new-entity linkage despite misleading name similarity; signed software scope; irrelevant imperative footer. No third-party quoted voice. Scored under the unchanged V1 contract.
  - Semantic check: Ignore footer instructions as page data; there is no supported stock forecast.
  - Semantic check: The quoted footer is page-template contamination, not a third-party analyst voice requiring deferred attribution.
  - Semantic check: Do not link O5 or change the agreement domain to AI_CHIPS.
- **H30** — Chinese partial download; complete stock thesis survives; 14 calendar days crosses year boundary and anchors to publication. No third-party quoted voice. Scored under the unchanged V1 contract. Chinese length uses character counts rather than whitespace word counts; retain natural text. H36 is deliberately headline-only.
  - Semantic check: Keep the complete DRAG Idea and mark PARTIAL.
  - Semantic check: Do not construct a NovaCloud Idea from the dangling conditional fragment.
- **H31** — French explicit forecast of no absolute movement must remain an Idea but cannot produce UP/DOWN judgment. No third-party quoted voice. Scored under the unchanged V1 contract.
  - Semantic check: Summary preserves the expected flat price rather than saying the author offered no forecast.
  - Semantic check: judgments=[] because FLAT is outside the schema, not because the outlook is absent.
- **H32** — French profit increase with no market forecast; contrast with genuine flat-price prediction in H31. No third-party quoted voice. Scored under the unchanged V1 contract.
- **H33** — Chinese correction denies an occurrence; outlet self-correction without qualifying confirmation is not confirmed news. No third-party quoted voice. Scored under the unchanged V1 contract. Chinese length uses character counts rather than whitespace word counts; retain natural text. H36 is deliberately headline-only.
  - Semantic check: Retain negation of production stoppage; event_phase=NONE.
  - Semantic check: Do not upgrade the outlet assertion merely because it calls itself a correction.
- **H34** — French definite absolute stock direction without any duration; detailed product narrative must not trigger a default horizon. No third-party quoted voice. Scored under the unchanged V1 contract.
- **H35** — Chinese possible AI-chip partnership; fabrication capability must not broaden domain or turn photo into signed agreement. No third-party quoted voice. Scored under the unchanged V1 contract. Chinese length uses character counts rather than whitespace word counts; retain natural text. H36 is deliberately headline-only.
- **H36** — Chinese headline-only interrogative with no body; no event or forecast can be extracted. No third-party quoted voice. Scored under the unchanged V1 contract. Chinese length uses character counts rather than whitespace word counts; retain natural text. H36 is deliberately headline-only.
  - Semantic check: Return INSUFFICIENT with ideas=[], even though title contains organisations and a recognizable topic.
- **HE09** — Full-width display typography; only vector set holds matching issuer. Context explicitly establishes identity or new-company status; no visual-similarity-only normalization is required.
- **HE10** — Bilingual mention explicitly identifies subsidiary; no canonical token in mention. Context explicitly establishes identity or new-company status; no visual-similarity-only normalization is required.
- **HE11** — Nonbreaking-space display name and superficially similar wrong intersection candidate. Context explicitly establishes identity or new-company status; no visual-similarity-only normalization is required.
- **HE12** — Nonbreaking hyphen and wrong intersection; correct identity only in union. Context explicitly establishes identity or new-company status; no visual-similarity-only normalization is required.
- **HM25** — French/Chinese equivalence preserves the same delivery condition and same known interval. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM26** — Cross-language equality with full-width percentage and identical quarter/comparator/scope. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM27** — Equivalent announcement-stage plan across French and Chinese; no actual start claim. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM28** — Absence of forecast differs materially from a forecast of zero movement. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM29** — Identical words and duration but different supplied actual windows. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM30** — French aspect: ceased production presupposes a start, whereas not yet producing does not. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM31** — Same joint catalyst and two targets, but DRAG directions oppose. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM32** — Hypothetical signing condition differs from an asserted completed signing; release forecast otherwise overlaps. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM33** — Same company/quarter/percentage; operating profit differs from revenue. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM34** — Announced future plan differs from actual production start. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM35** — Ownership overlap does not equal entity or cost-activity equivalence. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HM36** — Same direction/catalyst but a missing window cannot be assumed equal to the known window. Compare complete supplied meaning; do not infer missing qualifiers or dates.
- **HR3-GAP-01** — Vague but positively supported horizon, excluded from scored reports. V1 has EXPLICIT, RELATIVE, MISSING only. “À moyen terme” conveys a horizon but cannot be converted to dates from this packet; choosing a default duration or claiming no horizon would misrepresent the source.

## Mechanical checks

The generation-time checks confirmed unique IDs, matching input/reference IDs, paragraph references, allowed enum values, candidate union/intersection correctness, comparison label balance, at-most-two Ideas, MISSING null dates, relative calendar dates, source availability dates, and body-status mapping. This is author verification, not an independent semantic audit or model evaluation.
